from pathlib import Path
from runpy import run_path


evaluate_gate = run_path(
    str(Path(__file__).parents[1] / "bench/m31_0004_stability_release_gate.py")
)["evaluate_gate"]
categories = {
    name: [{"status": "PASS", "wall_ms": 1.0} for _ in range(10)]
    for name in ("cold", "warm", "agent")
}
payload = {
    "upstream": {name: "PASS" for name in (
        "M31-0001", "M31-0002", "M31-0003", "candidate-clean-gate"
    )},
    "vram_drift": {"min_bytes": 1, "max_bytes": 1, "delta_bytes": 0},
    "gpu_errors": [],
    "oom": [],
    "state_leaks": [],
}

assert evaluate_gate(categories, payload)[0]
assert not evaluate_gate(categories, {**payload, "upstream": {}})[0]
assert not evaluate_gate(categories, {
    **payload,
    "upstream": {key: value for key, value in payload["upstream"].items() if key != "candidate-clean-gate"},
})[0]
assert not evaluate_gate(categories, {**payload, "oom": ["OOM"]})[0]
assert not evaluate_gate(categories, {**payload, "vram_drift": None})[0]
assert not evaluate_gate({**categories, "cold": [{"wall_ms": 1.0}] * 10}, payload)[0]
