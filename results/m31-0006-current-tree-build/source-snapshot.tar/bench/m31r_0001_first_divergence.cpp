#include "miinfer/hip_check.hpp"
#define private public
#include "miinfer/prefill_v2/model.hpp"
#undef private
#include "miinfer/qwen35_model.hpp"

#include <cstdint>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

using Model = miinfer::prefill_v2::PrefillV2Model;
using Options = miinfer::prefill_v2::GenerateOptions;

namespace {

struct Fingerprint {
    std::uint64_t state_hash = 0;
    std::uint64_t history_hash = 0;
    std::uint64_t hidden_hash = 0;
    std::uint64_t all_state_hash = 0;
    std::uint64_t all_history_hash = 0;
    std::uint64_t all_kv_hash = 0;
    std::uint64_t kv_hash = 0;
    std::vector<std::uint32_t> positions;
};

std::uint64_t hash_bytes(std::uint64_t hash, const void* data, std::size_t bytes) {
    const auto* input = static_cast<const std::uint8_t*>(data);
    for (std::size_t i = 0; i < bytes; ++i) {
        hash ^= input[i];
        hash *= 1099511628211ULL;
    }
    return hash;
}

std::uint64_t hash_kv_range(Model& engine, std::size_t begin, std::size_t tokens) {
    const auto& kv = engine.kv_storage(0);
    std::vector<std::uint8_t> raw(kv.raw_tokens_bytes(tokens));
    kv.download_raw_range(raw.data(), begin, tokens);
    return hash_bytes(1469598103934665603ULL, raw.data(), raw.size());
}

Fingerprint capture(Model& engine, std::size_t position, bool all_layers = false) {
    Fingerprint result;
    std::vector<float> state;
    std::vector<float> history;
    engine.recurrent_storage(0).download(state, history);
    result.state_hash = hash_bytes(1469598103934665603ULL, state.data(), state.size() * sizeof(float));
    result.history_hash = hash_bytes(1469598103934665603ULL, history.data(), history.size() * sizeof(float));
    std::vector<float> hidden(miinfer::prefill_v2::kHidden);
    MIINFER_HIP_CHECK(hipMemcpy(hidden.data(), engine.d_pong_, hidden.size() * sizeof(float), hipMemcpyDeviceToHost));
    result.hidden_hash = hash_bytes(1469598103934665603ULL, hidden.data(), hidden.size() * sizeof(float));
    result.all_state_hash = result.state_hash;
    result.all_history_hash = result.history_hash;
    result.positions.push_back(engine.recurrent_states()[0].position());
    if (all_layers) {
        result.all_state_hash = 1469598103934665603ULL;
        result.all_history_hash = 1469598103934665603ULL;
        result.positions.clear();
        for (std::size_t i = 0; i < engine.recurrent_states().size(); ++i) {
            engine.recurrent_storage(i).download(state, history);
            result.all_state_hash = hash_bytes(result.all_state_hash, state.data(), state.size() * sizeof(float));
            result.all_history_hash = hash_bytes(result.all_history_hash, history.data(), history.size() * sizeof(float));
            result.positions.push_back(engine.recurrent_states()[i].position());
        }
    }

    result.all_kv_hash = 1469598103934665603ULL;
    for (std::size_t layer = 0; layer < engine.kv_caches().size(); ++layer) {
        const auto& layer_kv = engine.kv_storage(layer);
        const auto bytes = layer_kv.raw_tokens_bytes(1);
        std::vector<std::uint8_t> layer_raw(bytes);
        for (const auto token : {std::size_t(0), std::size_t(8191), position}) {
            if (token >= layer_kv.capacity()) continue;
            layer_kv.download_raw_range(layer_raw.data(), token, 1);
            result.all_kv_hash = hash_bytes(result.all_kv_hash ^ (layer * 1315423911ULL + token), layer_raw.data(), layer_raw.size());
        }
    }

    // Sample the KV boundary and current position without copying the full cache.
    const auto& kv = engine.kv_storage(0);
    const auto bytes = kv.raw_tokens_bytes(1);
    std::vector<std::uint8_t> raw(bytes);
    for (const auto token : {std::size_t(0), std::size_t(4095), std::size_t(8191), position}) {
        if (token >= kv.capacity()) continue;
        kv.download_raw_range(raw.data(), token, 1);
        result.kv_hash = hash_bytes(result.kv_hash ^ token, raw.data(), raw.size());
    }
    return result;
}

Options generate_options(std::size_t max_new, bool reuse, bool reset) {
    Options result;
    result.max_new_tokens = max_new;
    result.reset_state_before = reset;
    result.use_hip_graph = false;
    result.enable_prefix_reuse = reuse;
    result.temperature = 0.0F;
    result.top_p = 1.0F;
    result.top_k = 1;
    result.stop_token_ids.clear();
    result.seed = 7;
    return result;
}

} // namespace

int main(int argc, char** argv) {
    if (argc < 2 || argc > 3) {
        std::cerr << "usage: miinfer-m31r-0001-first-divergence MODEL.gguf [suffix_tokens]\n";
        return 2;
    }
    try {
        const auto model = miinfer::Qwen35Model::load(argv[1]);
        std::vector<std::uint32_t> prefix(8192);
        const std::size_t suffix_length = argc == 3 ? std::stoul(argv[2]) : 512;
        std::vector<std::uint32_t> suffix(suffix_length);
        std::uint32_t value = 77;
        for (auto& token : prefix) { value = value * 1664525u + 1013904223u; token = value % 151000u + 1u; }
        value = 177;
        for (auto& token : suffix) { value = value * 1664525u + 1013904223u; token = value % 151000u + 1u; }
        auto full = prefix;
        full.insert(full.end(), suffix.begin(), suffix.end());

        Model engine(model, 16384, true);
        hipStream_t stream = nullptr;
        MIINFER_HIP_CHECK(hipStreamCreate(&stream));
        std::vector<std::uint32_t> cold_tokens;
        std::vector<Fingerprint> cold_fingerprints;
        std::uint64_t cold_suffix_kv_hash = 0;
        auto cold = generate_options(32, false, true);
        cold.on_token = [&](std::uint32_t token) {
            cold_tokens.push_back(token);
            cold_fingerprints.push_back(capture(engine, full.size() + cold_tokens.size() - 1, cold_tokens.size() <= 2));
            if (cold_tokens.size() == 1) {
                cold_suffix_kv_hash = hash_kv_range(engine, prefix.size(), suffix.size());
            }
            return true;
        };
        (void)engine.generate(full, cold, stream);

        engine.reset_state();
        auto cold_prefix = generate_options(0, false, true);
        (void)engine.generate(prefix, cold_prefix, stream);
        const auto cold_prefix_fingerprint = capture(engine, prefix.size() - 1, true);
        const auto cold_prefix_kv_hash = hash_kv_range(engine, 0, prefix.size());

        engine.reset_state();
        auto prime = generate_options(0, false, true);
        prime.cache_prefix_after = true;
        prime.cache_prefix_len = prefix.size();
        (void)engine.generate(prefix, prime, stream);

        const auto restored_prefix_fingerprint = capture(engine, prefix.size() - 1, true);
        const auto restored_prefix_kv_hash = hash_kv_range(engine, 0, prefix.size());

        std::vector<std::uint32_t> reuse_tokens;
        std::vector<Fingerprint> reuse_fingerprints;
        std::uint64_t reuse_suffix_kv_hash = 0;
        auto reuse = generate_options(32, true, false);
        reuse.on_token = [&](std::uint32_t token) {
            reuse_tokens.push_back(token);
            reuse_fingerprints.push_back(capture(engine, full.size() + reuse_tokens.size() - 1, reuse_tokens.size() <= 2));
            if (reuse_tokens.size() == 1) {
                reuse_suffix_kv_hash = hash_kv_range(engine, prefix.size(), suffix.size());
            }
            return true;
        };
        const auto reuse_stats = engine.generate(full, reuse, stream);

        std::size_t token_mismatch = 0;
        while (token_mismatch < cold_tokens.size() && token_mismatch < reuse_tokens.size()
               && cold_tokens[token_mismatch] == reuse_tokens[token_mismatch]) ++token_mismatch;
        std::size_t state_mismatch = 0;
        while (state_mismatch < cold_fingerprints.size() && state_mismatch < reuse_fingerprints.size()) {
            const auto& cold_fingerprint = cold_fingerprints[state_mismatch];
            const auto& reuse_fingerprint = reuse_fingerprints[state_mismatch];
            if (cold_fingerprint.state_hash != reuse_fingerprint.state_hash
                || cold_fingerprint.history_hash != reuse_fingerprint.history_hash
                || cold_fingerprint.hidden_hash != reuse_fingerprint.hidden_hash
                || cold_fingerprint.all_state_hash != reuse_fingerprint.all_state_hash
                || cold_fingerprint.all_history_hash != reuse_fingerprint.all_history_hash
                || cold_fingerprint.all_kv_hash != reuse_fingerprint.all_kv_hash
                || cold_fingerprint.kv_hash != reuse_fingerprint.kv_hash
                || cold_fingerprint.positions != reuse_fingerprint.positions) break;
            ++state_mismatch;
        }

        std::cout << "M31R-0001 first-divergence: "
                  << (token_mismatch == cold_tokens.size() ? "PASS" : "FAIL") << '\n'
                  << "reuse_hit=" << reuse_stats.reuse_hit
                  << "token_mismatch_index=" << token_mismatch
                  << "cold_tokens=" << cold_tokens.size()
                  << "reuse_tokens=" << reuse_tokens.size()
                  << "state_mismatch_index=" << state_mismatch;
        std::cout << " prefix_state_equal="
                  << (cold_prefix_fingerprint.state_hash == restored_prefix_fingerprint.state_hash
                      && cold_prefix_fingerprint.history_hash == restored_prefix_fingerprint.history_hash
                      && cold_prefix_fingerprint.all_state_hash == restored_prefix_fingerprint.all_state_hash
                      && cold_prefix_fingerprint.all_history_hash == restored_prefix_fingerprint.all_history_hash
                      ? 1 : 0)
                  << " cold_prefix_state_hash=0x" << std::hex << cold_prefix_fingerprint.state_hash
                  << " restored_prefix_state_hash=0x" << restored_prefix_fingerprint.state_hash
                  << " cold_prefix_all_state_hash=0x" << cold_prefix_fingerprint.all_state_hash
                  << " restored_prefix_all_state_hash=0x" << restored_prefix_fingerprint.all_state_hash
                  << " cold_prefix_kv_hash=0x" << cold_prefix_kv_hash
                  << " restored_prefix_kv_hash=0x" << restored_prefix_kv_hash
                  << " cold_suffix_kv_hash=0x" << cold_suffix_kv_hash
                  << " reuse_suffix_kv_hash=0x" << reuse_suffix_kv_hash << std::dec;
        if (token_mismatch < cold_tokens.size() && token_mismatch < reuse_tokens.size()) {
            std::cout << " expected_token=" << cold_tokens[token_mismatch]
                      << " actual_token=" << reuse_tokens[token_mismatch];
        }
        if (state_mismatch < cold_fingerprints.size() && state_mismatch < reuse_fingerprints.size()) {
            const auto& c = cold_fingerprints[state_mismatch];
            const auto& r = reuse_fingerprints[state_mismatch];
            std::cout << " cold_state_hash=0x" << std::hex << c.state_hash
                      << " reuse_state_hash=0x" << r.state_hash
                      << " cold_history_hash=0x" << c.history_hash
                      << " reuse_history_hash=0x" << r.history_hash
                      << " cold_hidden_hash=0x" << c.hidden_hash
                      << " reuse_hidden_hash=0x" << r.hidden_hash
                      << " cold_all_state_hash=0x" << c.all_state_hash
                      << " reuse_all_state_hash=0x" << r.all_state_hash
                      << " cold_all_history_hash=0x" << c.all_history_hash
                      << " reuse_all_history_hash=0x" << r.all_history_hash
                      << " cold_all_kv_hash=0x" << c.all_kv_hash
                      << " reuse_all_kv_hash=0x" << r.all_kv_hash
                      << " cold_pos0=" << (c.positions.empty() ? 0 : c.positions.front())
                      << " reuse_pos0=" << (r.positions.empty() ? 0 : r.positions.front())
                      << " cold_poslast=" << (c.positions.empty() ? 0 : c.positions.back())
                      << " reuse_poslast=" << (r.positions.empty() ? 0 : r.positions.back())
                      << " cold_kv_hash=0x" << c.kv_hash
                      << " reuse_kv_hash=0x" << r.kv_hash << std::dec;
        }
        if (cold_fingerprints.size() > 1 && reuse_fingerprints.size() > 1) {
            const auto& c = cold_fingerprints[1];
            const auto& r = reuse_fingerprints[1];
            std::cout << " decode1_cold_hidden_hash=0x" << std::hex << c.hidden_hash
                      << " decode1_reuse_hidden_hash=0x" << r.hidden_hash
                      << " decode1_cold_state_hash=0x" << c.state_hash
                      << " decode1_reuse_state_hash=0x" << r.state_hash
                      << " decode1_cold_kv_hash=0x" << c.kv_hash
                      << " decode1_reuse_kv_hash=0x" << r.kv_hash
                      << " decode1_cold_all_kv_hash=0x" << c.all_kv_hash
                      << " decode1_reuse_all_kv_hash=0x" << r.all_kv_hash
                      << " decode1_cold_pos0=" << (c.positions.empty() ? 0 : c.positions.front())
                      << " decode1_reuse_pos0=" << (r.positions.empty() ? 0 : r.positions.front())
                      << " decode1_cold_poslast=" << (c.positions.empty() ? 0 : c.positions.back())
                      << " decode1_reuse_poslast=" << (r.positions.empty() ? 0 : r.positions.back()) << std::dec;
        }
        std::cout << '\n';
        MIINFER_HIP_CHECK(hipStreamDestroy(stream));
        return token_mismatch == cold_tokens.size() ? 0 : 1;
    } catch (const std::exception& error) {
        std::cerr << "M31R-0001 first-divergence: ERROR: " << error.what() << '\n';
        return 1;
    }
}
