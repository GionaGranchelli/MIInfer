#include "miinfer/hip_check.hpp"
#define private public
#include "miinfer/prefill_v2/model.hpp"
#undef private
#include "miinfer/qwen35_model.hpp"

#include <cstdint>
#include <cstdio>
#include <iostream>
#include <vector>

using Model = miinfer::prefill_v2::PrefillV2Model;

namespace miinfer {
void m31r_compute_copy(const float* source, float* destination, std::size_t count, hipStream_t stream);
}

namespace {

std::uint64_t hash_bytes(std::uint64_t hash, const void* data, std::size_t bytes) {
    const auto* input = static_cast<const std::uint8_t*>(data);
    for (std::size_t i = 0; i < bytes; ++i) {
        hash ^= input[i];
        hash *= 1099511628211ULL;
    }
    return hash;
}

struct Fingerprint { std::uint64_t state = 0; std::uint64_t history = 0; std::uint64_t kv = 0; };

std::uint64_t hash_device(const float* device, std::size_t elements) {
    std::vector<float> host(elements);
    MIINFER_HIP_CHECK(hipMemcpy(host.data(), device, elements * sizeof(float), hipMemcpyDeviceToHost));
    return hash_bytes(1469598103934665603ULL, host.data(), host.size() * sizeof(float));
}

struct InternalFingerprint {
    std::uint64_t ping = 0;
    std::uint64_t pong = 0;
    std::uint64_t normalized = 0;
    std::uint64_t query = 0;
    std::uint64_t key = 0;
    std::uint64_t value = 0;
    std::uint64_t beta = 0;
    std::uint64_t decay = 0;
};

InternalFingerprint capture_internal(Model& engine) {
    constexpr std::size_t tokens = miinfer::prefill_v2::kMaxPrefillBatch;
    const auto& ws = engine.workspace();
    return {
        hash_device(engine.d_ping_, tokens * miinfer::prefill_v2::kHidden),
        hash_device(engine.d_pong_, tokens * miinfer::prefill_v2::kHidden),
        hash_device(ws.normalized, tokens * miinfer::prefill_v2::kHidden),
        hash_device(ws.query, tokens * miinfer::prefill_v2::kKHeads * miinfer::prefill_v2::kState),
        hash_device(ws.key, tokens * miinfer::prefill_v2::kKHeads * miinfer::prefill_v2::kState),
        hash_device(ws.value, tokens * miinfer::prefill_v2::kVHeads * miinfer::prefill_v2::kState),
        hash_device(ws.beta, tokens * miinfer::prefill_v2::kVHeads),
        hash_device(ws.decay, tokens * miinfer::prefill_v2::kVHeads)};
}

Fingerprint capture(Model& engine, std::size_t kv_begin, std::size_t kv_tokens) {
    Fingerprint result{1469598103934665603ULL, 1469598103934665603ULL, 1469598103934665603ULL};
    std::vector<float> state;
    std::vector<float> history;
    for (std::size_t i = 0; i < engine.recurrent_states().size(); ++i) {
        engine.recurrent_storage(i).download(state, history);
        result.state = hash_bytes(result.state, state.data(), state.size() * sizeof(float));
        result.history = hash_bytes(result.history, history.data(), history.size() * sizeof(float));
    }
    const auto& kv = engine.kv_storage(0);
    std::vector<std::uint8_t> raw(kv.raw_tokens_bytes(kv_tokens));
    kv.download_raw_range(raw.data(), kv_begin, kv_tokens);
    result.kv = hash_bytes(result.kv, raw.data(), raw.size());
    return result;
}

} // namespace

int main(int argc, char** argv) {
    if (argc != 2) {
        std::cerr << "usage: miinfer-m31r-0001-direct-suffix MODEL.gguf\n";
        return 2;
    }
    try {
        MIINFER_HIP_CHECK(hipInit(0));
        MIINFER_HIP_CHECK(hipSetDevice(0));
        const auto model = miinfer::Qwen35Model::load(argv[1]);
        std::size_t free_bytes = 0;
        std::size_t total_bytes = 0;
        MIINFER_HIP_CHECK(hipMemGetInfo(&free_bytes, &total_bytes));
        std::cerr << "after_model_load free=" << free_bytes << " total=" << total_bytes << '\n';
        void* allocation_probe = nullptr;
        MIINFER_HIP_CHECK(hipMalloc(&allocation_probe, 150994944));
        MIINFER_HIP_CHECK(hipFree(allocation_probe));
        std::cerr << "same_process_allocation=PASS\n";
        std::vector<std::uint32_t> prefix(257);
        std::vector<std::uint32_t> suffix(256);
        prefix[0] = 151644;
        for (std::size_t turn = 1; turn <= 2; ++turn) {
            std::uint32_t value = 1000u + 77u + static_cast<std::uint32_t>(turn * 17);
            const auto count = turn == 1 ? prefix.size() - 1 : suffix.size();
            auto* destination = turn == 1 ? prefix.data() + 1 : suffix.data();
            for (std::size_t i = 0; i < count; ++i) {
                value = value * 1664525u + 1013904223u;
                destination[i] = value % 151000u + 1u;
            }
        }

        Model engine(model, 16384, true);
        hipStream_t stream = nullptr;
        MIINFER_HIP_CHECK(hipStreamCreate(&stream));
        float* hidden = nullptr;
        MIINFER_HIP_CHECK(hipMalloc(&hidden, (prefix.size() + suffix.size()) * miinfer::prefill_v2::kHidden * sizeof(float)));

        engine.reset_state();
        engine.prefill_sequence(prefix, hidden, stream);
        MIINFER_HIP_CHECK(hipStreamSynchronize(stream));
        const auto cold_internal = capture_internal(engine);
        const auto cold_prefix = capture(engine, 0, prefix.size());
        engine.forward(suffix, static_cast<std::uint32_t>(prefix.size()), hidden, stream);
        MIINFER_HIP_CHECK(hipStreamSynchronize(stream));
        const auto cold = capture(engine, prefix.size(), suffix.size());
        const auto cold_full_context = capture(engine, 0, prefix.size() + suffix.size());

        engine.reset_state();
        engine.prefill_sequence(prefix, hidden, stream);
        MIINFER_HIP_CHECK(hipStreamSynchronize(stream));
        std::vector<std::vector<float>> host_states(engine.recurrent_states().size());
        std::vector<std::vector<float>> host_histories(engine.recurrent_states().size());
        for (std::size_t i = 0; i < engine.recurrent_states().size(); ++i) {
            engine.recurrent_storage(i).download(host_states[i], host_histories[i]);
            engine.recurrent_storage(i).upload(host_states[i], host_histories[i], static_cast<std::uint32_t>(prefix.size()));
        }
        MIINFER_HIP_CHECK(hipDeviceSynchronize());
        const auto host_internal = capture_internal(engine);
        engine.forward(suffix, static_cast<std::uint32_t>(prefix.size()), hidden, stream);
        MIINFER_HIP_CHECK(hipStreamSynchronize(stream));
        const auto host_reupload = capture(engine, prefix.size(), suffix.size());

        engine.reset_state();
        engine.prefill_sequence(prefix, hidden, stream);
        MIINFER_HIP_CHECK(hipStreamSynchronize(stream));
        host_states.assign(engine.recurrent_states().size(), {});
        host_histories.assign(engine.recurrent_states().size(), {});
        for (std::size_t i = 0; i < engine.recurrent_states().size(); ++i) {
            engine.recurrent_storage(i).download(host_states[i], host_histories[i]);
            miinfer::prefill_v2::RecurrentLayerStateStorage replacement;
            replacement.upload(host_states[i], host_histories[i], static_cast<std::uint32_t>(prefix.size()));
            engine.recurrent_storage(i) = std::move(replacement);
        }
        MIINFER_HIP_CHECK(hipDeviceSynchronize());
        engine.forward(suffix, static_cast<std::uint32_t>(prefix.size()), hidden, stream);
        MIINFER_HIP_CHECK(hipStreamSynchronize(stream));
        const auto fresh_state = capture(engine, prefix.size(), suffix.size());

        engine.reset_state();
        engine.prefill_sequence(prefix, hidden, stream);
        MIINFER_HIP_CHECK(hipStreamSynchronize(stream));
        for (std::size_t i = 0; i < engine.recurrent_states().size(); ++i) {
            const auto source = engine.recurrent_storage(i).view();
            miinfer::prefill_v2::RecurrentLayerStateStorage replacement;
            const auto destination = replacement.view();
            miinfer::m31r_compute_copy(source.d_state, destination.d_state,
                                       miinfer::prefill_v2::RecurrentLayerState::kStateElements, stream);
            miinfer::m31r_compute_copy(source.d_conv_history, destination.d_conv_history,
                                       miinfer::prefill_v2::RecurrentLayerState::kConvHistoryElements, stream);
            replacement.set_position(static_cast<std::uint32_t>(prefix.size()));
            engine.recurrent_storage(i) = std::move(replacement);
        }
        MIINFER_HIP_CHECK(hipStreamSynchronize(stream));
        engine.forward(suffix, static_cast<std::uint32_t>(prefix.size()), hidden, stream);
        MIINFER_HIP_CHECK(hipStreamSynchronize(stream));
        const auto compute_copy = capture(engine, prefix.size(), suffix.size());

        engine.reset_state();
        engine.prefill_sequence(prefix, hidden, stream);
        MIINFER_HIP_CHECK(hipStreamSynchronize(stream));
        engine.reusable_context().save(prefix, engine.recurrent_states(), hidden + (prefix.size() - 1) * miinfer::prefill_v2::kHidden, stream);
        MIINFER_HIP_CHECK(hipStreamSynchronize(stream));
        engine.forward(suffix, static_cast<std::uint32_t>(prefix.size()), hidden, stream);
        MIINFER_HIP_CHECK(hipStreamSynchronize(stream));
        const auto saved_no_restore = capture(engine, prefix.size(), suffix.size());

        engine.reset_state();
        engine.prefill_sequence(prefix, hidden, stream);
        MIINFER_HIP_CHECK(hipStreamSynchronize(stream));
        engine.reusable_context().save(prefix, engine.recurrent_states(), hidden + (prefix.size() - 1) * miinfer::prefill_v2::kHidden, stream);
        MIINFER_HIP_CHECK(hipStreamSynchronize(stream));
        engine.restore_reusable_context(nullptr);
        MIINFER_HIP_CHECK(hipDeviceSynchronize());
        MIINFER_HIP_CHECK(hipDeviceSynchronize());
        const auto restored_internal = capture_internal(engine);
        const auto restored_prefix = capture(engine, 0, prefix.size());
        engine.forward(suffix, static_cast<std::uint32_t>(prefix.size()), hidden, stream);
        MIINFER_HIP_CHECK(hipStreamSynchronize(stream));
        const auto reused = capture(engine, prefix.size(), suffix.size());

        engine.reset_state();
        engine.prefill_sequence(prefix, hidden, stream);
        engine.forward(suffix, static_cast<std::uint32_t>(prefix.size()), hidden, stream);
        MIINFER_HIP_CHECK(hipStreamSynchronize(stream));
        const auto batched = capture(engine, prefix.size(), suffix.size());

        engine.reset_state();
        engine.prefill_sequence(prefix, hidden, stream);
        for (std::size_t i = 0; i < suffix.size(); ++i) {
            engine.forward(std::span<const std::uint32_t>(&suffix[i], 1),
                           static_cast<std::uint32_t>(prefix.size() + i), hidden, stream);
        }
        MIINFER_HIP_CHECK(hipStreamSynchronize(stream));
        const auto stepwise = capture(engine, prefix.size(), suffix.size());
        const bool batch_shape_equal = batched.state == stepwise.state
            && batched.history == stepwise.history && batched.kv == stepwise.kv;

        const auto run_generation = [&](std::size_t generated, bool reuse, bool reset,
                                        bool cache, bool graph) {
            miinfer::prefill_v2::GenerateOptions options;
            options.max_new_tokens = generated;
            options.enable_prefix_reuse = reuse;
            options.reset_state_before = reset;
            options.cache_prefix_after = cache;
            options.use_hip_graph = graph;
            options.temperature = 0.0F;
            options.top_p = 1.0F;
            options.top_k = 1;
            options.stop_token_ids.clear();
            options.seed = 7;
            return options;
        };
        auto full_prompt = prefix;
        full_prompt.insert(full_prompt.end(), suffix.begin(), suffix.end());
        bool generation_parity = true;
        for (const bool graph : {false, true}) {
            engine.reset_state();
            const auto cold_output = engine.generate(
                full_prompt, run_generation(32, false, true, false, graph)).generated_tokens;
            engine.reset_state();
            (void)engine.generate(prefix, run_generation(32, false, true, true, graph));
            const auto reused_output = engine.generate(
                full_prompt, run_generation(32, true, false, false, graph)).generated_tokens;
            if (cold_output != reused_output) {
                generation_parity = false;
                std::size_t mismatch = 0;
                while (mismatch < cold_output.size() && mismatch < reused_output.size()
                       && cold_output[mismatch] == reused_output[mismatch]) ++mismatch;
                std::cout << "generate_after_cached_decode graph=" << (graph ? 1 : 0)
                          << " parity=FAIL first_divergence=" << mismatch;
                if (mismatch < cold_output.size()) std::cout << " cold=" << cold_output[mismatch];
                if (mismatch < reused_output.size()) std::cout << " reused=" << reused_output[mismatch];
                std::cout << '\n';
            } else {
                std::cout << "generate_after_cached_decode graph=" << (graph ? 1 : 0)
                          << " parity=PASS\n";
            }
        }
        engine.reset_state();
        engine.prefill_sequence(full_prompt, hidden, stream);
        MIINFER_HIP_CHECK(hipStreamSynchronize(stream));
        const auto cold_whole_prompt = capture(engine, 0, full_prompt.size());
        const bool chunk_shape_equal = cold_full_context.state == cold_whole_prompt.state
            && cold_full_context.history == cold_whole_prompt.history
            && cold_full_context.kv == cold_whole_prompt.kv;
        std::cout << "full_prompt_vs_prefix_suffix parity="
                  << (chunk_shape_equal ? "PASS" : "FAIL")
                  << " split_state=0x" << std::hex << cold_full_context.state
                  << " whole_state=0x" << cold_whole_prompt.state
                  << " split_history=0x" << cold_full_context.history
                  << " whole_history=0x" << cold_whole_prompt.history
                  << " split_kv=0x" << cold_full_context.kv
                  << " whole_kv=0x" << cold_whole_prompt.kv << std::dec << '\n';

        std::cout << "M31R-0001 direct-suffix: " << ((cold.state == reused.state && cold.history == reused.history && cold.kv == reused.kv) ? "PASS" : "FAIL")
                  << " prefix_equal=" << ((cold_prefix.state == restored_prefix.state && cold_prefix.history == restored_prefix.history && cold_prefix.kv == restored_prefix.kv) ? 1 : 0)
                  << " cold_state=0x" << std::hex << cold.state << " reused_state=0x" << reused.state
                  << " cold_history=0x" << cold.history << " reused_history=0x" << reused.history
                  << " cold_kv=0x" << cold.kv << " reused_kv=0x" << reused.kv
                  << " host_reupload_state=0x" << host_reupload.state
                  << " host_reupload_history=0x" << host_reupload.history
                  << " host_reupload_kv=0x" << host_reupload.kv
                  << " fresh_state=0x" << fresh_state.state
                  << " fresh_history=0x" << fresh_state.history
                  << " fresh_kv=0x" << fresh_state.kv
                  << " compute_copy_state=0x" << compute_copy.state
                  << " compute_copy_history=0x" << compute_copy.history
                  << " compute_copy_kv=0x" << compute_copy.kv
                  << " no_restore_state=0x" << saved_no_restore.state
                  << " no_restore_history=0x" << saved_no_restore.history
                  << " no_restore_kv=0x" << saved_no_restore.kv
                  << " cold_prefix_state=0x" << cold_prefix.state << " restored_prefix_state=0x" << restored_prefix.state
                  << " cold_prefix_history=0x" << cold_prefix.history << " restored_prefix_history=0x" << restored_prefix.history
                  << " cold_prefix_kv=0x" << cold_prefix.kv << " restored_prefix_kv=0x" << restored_prefix.kv << std::dec << '\n';
        std::cout << "two_token_batch_vs_stepwise=" << (batch_shape_equal ? "PASS" : "FAIL")
                  << " batched_state=0x" << std::hex << batched.state << " stepwise_state=0x" << stepwise.state
                  << " batched_history=0x" << batched.history << " stepwise_history=0x" << stepwise.history
                  << " batched_kv=0x" << batched.kv << " stepwise_kv=0x" << stepwise.kv << std::dec << '\n';
        std::cout << "M31R-0001 internal: cold_ping=0x" << std::hex << cold_internal.ping
                  << " host_ping=0x" << host_internal.ping << " restored_ping=0x" << restored_internal.ping
                  << " cold_pong=0x" << cold_internal.pong << " host_pong=0x" << host_internal.pong
                  << " restored_pong=0x" << restored_internal.pong
                  << " cold_norm=0x" << cold_internal.normalized << " host_norm=0x" << host_internal.normalized
                  << " restored_norm=0x" << restored_internal.normalized
                  << " cold_query=0x" << cold_internal.query << " host_query=0x" << host_internal.query
                  << " restored_query=0x" << restored_internal.query
                  << " cold_key=0x" << cold_internal.key << " host_key=0x" << host_internal.key
                  << " restored_key=0x" << restored_internal.key
                  << " cold_value=0x" << cold_internal.value << " host_value=0x" << host_internal.value
                  << " restored_value=0x" << restored_internal.value << std::dec << '\n';

        MIINFER_HIP_CHECK(hipFree(hidden));
        MIINFER_HIP_CHECK(hipStreamDestroy(stream));
        return (cold.state == reused.state && cold.history == reused.history && cold.kv == reused.kv
                && batch_shape_equal && generation_parity && chunk_shape_equal) ? 0 : 1;
    } catch (const std::exception& error) {
        std::cerr << "M31R-0001 direct-suffix: ERROR: " << error.what() << '\n';
        return 1;
    }
}
