#pragma once

#include "miinfer/prefill_v2/constants.hpp"
#include "miinfer/generation_contract.hpp"
#include "miinfer/prefill_v2/kv_cache.hpp"
#include "miinfer/prefill_v2/reusable_context.hpp"
#include "miinfer/prefill_v2/state.hpp"
#include "miinfer/prefill_v2/topology_block.hpp"
#include "miinfer/prefill_v2/workspace.hpp"
#include "miinfer/qwen35_model.hpp"

#include <hip/hip_runtime_api.h>

#include <cstddef>
#include <cstdint>
#include <memory>
#include <optional>
#include <unordered_map>
#include <vector>
#include <span>
#include <string>

#include <functional>
#include <random>

namespace miinfer::prefill_v2 {

struct GenerateOptions {
    std::size_t max_new_tokens = 128;
    bool reset_state_before = true;
    bool use_hip_graph = true;
    bool enable_prefix_reuse = false;   // When true, attempts to reuse cached prefix if matching
    bool cache_prefix_after = false;    // When true, caches prefix state after prefill
    std::size_t cache_prefix_len = 0;   // If 0, caches entire prompt; otherwise first N tokens
    std::vector<std::uint32_t> stop_token_ids = {151643, 151645};
    float temperature = 0.7f;
    float top_p = 0.9f;
    std::uint32_t top_k = 40;
    std::optional<std::uint32_t> seed;
    float repetition_penalty = 1.15f;
    float presence_penalty = 0.0f;
    float frequency_penalty = 0.0f;
    std::size_t repeat_last_n = 256;
    std::string persistent_session_dir; // When non-empty, restores from and saves prefix sessions to this dir
    std::function<void(std::uint32_t, std::uint32_t)> on_prefill_progress = nullptr;
    std::function<bool(std::uint32_t)> on_token = nullptr;
};

struct GenerateStats {
    miinfer::GenerationStopReason stop_reason = miinfer::GenerationStopReason::kOutputLimit;
    std::vector<std::uint32_t> prompt_tokens;
    std::vector<std::uint32_t> generated_tokens;
    double prefill_ms = 0.0;
    double ttft_ms = 0.0;
    double decode_ms = 0.0;
    double total_ms = 0.0;
    double prefill_tok_per_sec = 0.0;
    double decode_tok_per_sec = 0.0;
    double avg_decode_latency_ms = 0.0;
    bool used_hip_graph = false;

    // Reuse telemetry & observability
    bool reuse_hit = false;
    std::uint32_t prefix_tokens_reused = 0;
    std::uint32_t suffix_tokens_dispatched = 0;
    std::uint32_t suffix_tokens_executed = 0;
    std::uint32_t prefix_tokens_replayed = 0;
    std::uint32_t checkpoint_position = 0;
    std::uint32_t gqa_kv_reused_tokens = 0;
    std::uint32_t gdn_checkpoint_position = 0;
    double restore_ms = 0.0;
    double suffix_prefill_ms = 0.0;
    std::size_t persistent_checkpoint_count = 0;
    std::size_t persistent_checkpoint_bytes = 0;
};

struct ModelProfileBreakdown {
    double embedding_ms = 0.0;
    std::vector<TopologyBlockProfileBreakdown> block_breakdowns;
    double final_norm_ms = 0.0;
    double total_model_ms = 0.0;
};

struct ModelDecodeProfileBreakdown {
    std::vector<RecurrentLayerDecodePhaseTimings> recurrent_layers;
    std::vector<AttentionLayerDecodePhaseTimings> attention_layers;
    double host_to_device_ms = 0.0;
    double embedding_ms = 0.0;
    double final_norm_ms = 0.0;
    double logits_ms = 0.0;
    double argmax_ms = 0.0;
    double device_to_host_ms = 0.0;
    double device_timeline_ms = 0.0;
    double wall_ms = 0.0;
};

// Represents the complete 64-layer Prefill V2 model:
// - Token embedding table (Q4_K)
// - 16 Repeating Topology Blocks (48 GDN + 16 GQA = 64 layers)
// - Output RMS norm (F32)
// - LM Head Output Projection (Q6_K)
// - 48 Persistent RecurrentLayerStateStorage instances
// - 16 Persistent AttentionLayerKvCacheStorage instances
// - Monolithic Shared Workspace (sized for kMaxPrefillBatch = 512)
// - Ping-pong activation buffers
class PrefillV2Model {
public:
    using SnapshotId = std::uint64_t;
    static constexpr SnapshotId kInvalidSnapshotId = 0;

    struct SnapshotTelemetry {
        std::size_t logical_snapshot_count = 0;
        std::size_t physical_shared_bytes = 0;
        std::size_t private_branch_bytes = 0;
        std::size_t reference_count = 0;
        std::size_t cow_events = 0;
        std::size_t cow_bytes_copied = 0;
    };

    explicit PrefillV2Model(
        const miinfer::Qwen35Model& model,
        std::uint32_t kv_capacity = 32768,
        bool load_lm_head = true,
        KvCacheQuantMode kv_quant_mode = KvCacheQuantMode::kFp16Fp16);
    ~PrefillV2Model();

    PrefillV2Model(const PrefillV2Model&) = delete;
    PrefillV2Model& operator=(const PrefillV2Model&) = delete;
    PrefillV2Model(PrefillV2Model&&) noexcept;
    PrefillV2Model& operator=(PrefillV2Model&&) noexcept;

    [[nodiscard]] KvCacheQuantMode kv_quant_mode() const noexcept { return kv_quant_mode_; }

    // Reset all 48 recurrent states and 16 KV caches
    void reset_state();

    // Physical single-chunk forward execution through the 64-layer pipeline (token_count <= 512)
    // d_tokens: device pointer to token IDs [token_count]
    // base_position: starting token index in the sequence
    // token_count: number of tokens to process (must be <= kMaxPrefillBatch)
    // d_final_hidden_out: output buffer for normalized final hidden states [token_count, kHidden]
    void forward(
        const std::uint32_t* d_tokens,
        std::uint32_t base_position,
        std::uint32_t token_count,
        float* d_final_hidden_out,
        hipStream_t stream = nullptr,
        const DevicePrefillState* prefill_state = nullptr);

    // Host token overload: copies host tokens to temporary device buffer and calls forward
    void forward(
        std::span<const std::uint32_t> tokens,
        std::uint32_t base_position,
        float* d_final_hidden_out,
        hipStream_t stream = nullptr);

    // Profiled forward for a single chunk (token_count <= 512)
    void forward_profiled(
        const std::uint32_t* d_tokens,
        std::uint32_t base_position,
        std::uint32_t token_count,
        float* d_final_hidden_out,
        ModelProfileBreakdown& breakdown,
        hipStream_t stream = nullptr);

    // Native Full-Model Macro Scheduler (V2 Macro Tile = 512)
    // Sequentially executes arbitrarily long sequences in 512-token full-model macro tiles,
    // seamlessly advancing base_position and persisting all 48 recurrent states and 16 KV caches.
    void prefill_sequence(
        const std::uint32_t* d_tokens,
        std::uint32_t total_tokens,
        float* d_final_hidden_out,
        hipStream_t stream = nullptr);

    void prefill_sequence(
        std::span<const std::uint32_t> tokens,
        float* d_final_hidden_out,
        hipStream_t stream = nullptr);

    // Compute model logits for the final token from its normalized hidden state
    // d_final_hidden_last_token: pointer to normalized hidden state [kHidden]
    // d_logits_out: device pointer to output logits [vocab_size] (if nullptr, writes to internal d_logits_)
    void compute_logits(
        const float* d_final_hidden_last_token,
        float* d_logits_out = nullptr,
        hipStream_t stream = nullptr);

    // Single-Token Autoregressive Decode Step:
    // Takes input_token at sequence position `position`, executes the full 64-layer model,
    // updates persistent recurrent states and appends to persistent KV caches in place with ZERO copies,
    // computes next-token logits, and returns the newly generated token ID via device argmax.
    std::uint32_t decode_step(
        std::uint32_t input_token,
        std::uint32_t position,
        float* d_logits_out = nullptr,
        hipStream_t stream = nullptr);

    // Diagnostic eager decode path using existing per-layer HIP-event timers.
    // This synchronizes within layer profiles and is not a throughput path.
    std::uint32_t decode_step_profiled(
        std::uint32_t input_token,
        std::uint32_t position,
        ModelDecodeProfileBreakdown& breakdown,
        float* d_logits_out = nullptr,
        hipStream_t stream = nullptr);

    // End-to-End Generation Pipeline:
    // 1. Prefills the full prompt using native 512-token macro-tiling.
    // 2. Evaluates the initial token logits (TTFT).
    // 3. Hands off persistent recurrent states and KV caches directly to the autoregressive decode loop with ZERO device copies.
    // 4. Decodes up to max_new_tokens sequentially.
    GenerateStats generate(
        std::span<const std::uint32_t> prompt,
        const GenerateOptions& options = GenerateOptions(),
        hipStream_t stream = nullptr);

    // Accessors
    [[nodiscard]] std::size_t block_count() const noexcept { return blocks_.size(); }
    [[nodiscard]] const PrefillV2TopologyBlock& block(std::size_t idx) const { return *blocks_[idx]; }
    [[nodiscard]] const RecurrentLayerStateStorage& recurrent_storage(std::size_t gdn_idx) const { return recurrent_states_[gdn_idx]; }
    [[nodiscard]] RecurrentLayerStateStorage& recurrent_storage(std::size_t gdn_idx) { invalidate_runtime_state_cache(); return recurrent_states_[gdn_idx]; }
    [[nodiscard]] const std::vector<RecurrentLayerStateStorage>& recurrent_states() const noexcept { return recurrent_states_; }
    [[nodiscard]] std::vector<RecurrentLayerStateStorage>& recurrent_states() noexcept { invalidate_runtime_state_cache(); return recurrent_states_; }
    [[nodiscard]] const AttentionLayerKvCacheStorage& kv_storage(std::size_t gqa_idx) const { return kv_caches_[gqa_idx]; }
    [[nodiscard]] AttentionLayerKvCacheStorage& kv_storage(std::size_t gqa_idx) { invalidate_runtime_state_cache(); return kv_caches_[gqa_idx]; }
    [[nodiscard]] const std::vector<AttentionLayerKvCacheStorage>& kv_caches() const noexcept { return kv_caches_; }
    [[nodiscard]] std::vector<AttentionLayerKvCacheStorage>& kv_caches() noexcept { invalidate_runtime_state_cache(); return kv_caches_; }
    [[nodiscard]] PrefillV2Workspace& workspace() noexcept { return const_cast<PrefillV2Workspace&>(ws_mgr_->workspace()); }
    [[nodiscard]] std::uint32_t vocab_size() const noexcept { return vocab_size_; }
    [[nodiscard]] const std::string& model_name() const noexcept { return model_name_; }
    [[nodiscard]] const std::string& quantization() const noexcept { return quantization_; }

    // Reusable Context & Checkpoint Storage
    [[nodiscard]] const ReusableContext& reusable_context() const noexcept { return reusable_context_; }
    [[nodiscard]] ReusableContext& reusable_context() noexcept { invalidate_runtime_state_cache(); return reusable_context_; }
    [[nodiscard]] std::size_t cached_state_bytes() const noexcept { return reusable_context_.memory_bytes(); }
    void restore_reusable_context(hipStream_t stream = nullptr);

    // Persistent Session Save & Restore (V2-0028)
    void save_session(
        const std::string& file_path,
        std::span<const std::uint32_t> prefix_tokens,
        hipStream_t stream = nullptr) const;

    bool load_session(
        const std::string& file_path,
        std::vector<std::uint32_t>& out_prefix_tokens,
        hipStream_t stream = nullptr);

    bool restore_matching_session(
        const std::string& session_dir,
        std::span<const std::uint32_t> full_prompt,
        std::uint32_t& out_prefix_length,
        hipStream_t stream = nullptr);

    // Process-local agent snapshot lifecycle. Snapshot tokens must describe
    // the active full-model state at the time of capture.
    [[nodiscard]] SnapshotId snapshot(
        std::span<const std::uint32_t> tokens,
        hipStream_t stream = nullptr);
    [[nodiscard]] SnapshotId fork(SnapshotId source);
    bool restore_snapshot(SnapshotId id, hipStream_t stream = nullptr);
    bool rollback_snapshot(SnapshotId id, hipStream_t stream = nullptr);
    bool release_snapshot(SnapshotId id) noexcept;
    void clear_snapshots() noexcept;
    [[nodiscard]] std::size_t snapshot_count() const noexcept { return snapshots_.size(); }
    [[nodiscard]] std::size_t snapshot_bytes() const noexcept { return snapshot_bytes_; }
    [[nodiscard]] SnapshotTelemetry snapshot_telemetry() const noexcept;

    // Memory footprints
    [[nodiscard]] std::size_t persistent_weight_bytes() const noexcept;
    [[nodiscard]] std::size_t persistent_state_bytes() const noexcept;
    [[nodiscard]] std::size_t workspace_bytes() const noexcept;
    [[nodiscard]] std::size_t activation_bytes() const noexcept;
    [[nodiscard]] std::size_t total_vram_bytes() const noexcept;

    [[nodiscard]] const void* embedding_weights() const noexcept { return d_embedding_weights_; }
    [[nodiscard]] const float* final_norm_weights() const noexcept { return d_final_norm_weights_; }
    [[nodiscard]] const void* output_weights() const noexcept { return d_output_weights_; }
    [[nodiscard]] float* logits_buffer() noexcept { return d_logits_; }

    // Reusable Decode Graph Capture & Replay
    void capture_decode_graph(hipStream_t stream = nullptr);
    void cleanup_decode_graph();
    [[nodiscard]] bool is_decode_graph_captured() const noexcept { return decode_graph_exec_ != nullptr; }

    // Reusable Suffix Prefill Graph Capture & Replay (512-token macro tile)
    void capture_suffix_graph(hipStream_t stream = nullptr);
    void cleanup_suffix_graph();
    [[nodiscard]] bool is_suffix_graph_captured() const noexcept { return suffix_graph_exec_ != nullptr; }

private:
    struct SnapshotBacking {
        explicit SnapshotBacking(std::shared_ptr<SnapshotBacking> parent_backing = nullptr);
        ~SnapshotBacking();

        std::shared_ptr<SnapshotBacking> parent;
        std::size_t prefix_length = 0;
        std::size_t suffix_begin = 0;
        std::size_t suffix_tokens = 0;
        void* d_gdn = nullptr;
        void* d_kv_suffix = nullptr;
        float* d_final_hidden = nullptr;
        std::size_t bytes = 0;
        std::size_t references = 0;
    };

    struct SnapshotRecord {
        std::shared_ptr<SnapshotBacking> backing;
        std::vector<std::uint32_t> tokens;
        std::uint64_t last_used = 0;
    };

    void evict_snapshots_except(SnapshotId preserve) noexcept;
    [[nodiscard]] const SnapshotRecord* find_longest_snapshot_prefix(
        std::span<const std::uint32_t> tokens) const noexcept;
    [[nodiscard]] std::shared_ptr<SnapshotBacking> capture_snapshot_backing(
        std::span<const std::uint32_t> tokens, hipStream_t stream,
        bool use_parent = true);
    void restore_snapshot_backing(
        const std::shared_ptr<SnapshotBacking>& backing, hipStream_t stream,
        bool restore_gdn = true);
    void release_snapshot_record(SnapshotRecord& record) noexcept;
    void refresh_snapshot_bytes() noexcept;

    std::string model_name_ = "Qwen3.8-27B";
    std::string quantization_ = "Q4_K_M";
    std::uint32_t vocab_size_ = 0;
    float rms_epsilon_ = 1e-6f;
    std::uint32_t kv_capacity_ = 32768;
    KvCacheQuantMode kv_quant_mode_ = KvCacheQuantMode::kFp16Fp16;
    bool has_lm_head_ = false;

    // Reusable Context
    ReusableContext reusable_context_;

    // Weights on device
    void* d_embedding_weights_ = nullptr;     // Q4_K [vocab_size, hidden_size]
    std::size_t embedding_bytes_ = 0;
    float* d_final_norm_weights_ = nullptr;   // F32 [hidden_size]
    std::size_t final_norm_bytes_ = 0;
    void* d_output_weights_ = nullptr;        // Q6_K [vocab_size, hidden_size]
    std::size_t output_weight_bytes_ = 0;
    Q6KWaveTile* d_output_weights_wave_ = nullptr; // Gfx906 resident Wave Q6_K

    // LM Head Scratch & Logits Buffer
    void* d_lm_head_q8_k_ = nullptr;          // [kHidden / 256] Q8KDeviceBlock
    float* d_logits_ = nullptr;               // [vocab_size] float

    // 16 Blocks
    std::vector<std::unique_ptr<PrefillV2TopologyBlock>> blocks_;

    // States
    std::vector<RecurrentLayerStateStorage> recurrent_states_; // 48 states
    std::vector<AttentionLayerKvCacheStorage> kv_caches_;       // 16 KV caches

    // Shared Workspace & Ping-Pong Activation Buffers
    std::unique_ptr<PrefillV2WorkspaceManager> ws_mgr_;

    float* d_ping_ = nullptr; // [kMaxPrefillBatch * kHidden] floats
    float* d_pong_ = nullptr; // [kMaxPrefillBatch * kHidden] floats
    std::uint32_t* d_temp_tokens_ = nullptr; // [kMaxPrefillBatch] uint32_t

    // Reusable Device Decode State & Graph Exec
    void* d_decode_state_ = nullptr; // DeviceDecodeState
    std::uint32_t* d_decode_tokens_ = nullptr; // [kDefaultCacheCapacity] uint32_t
    hipGraphExec_t decode_graph_exec_ = nullptr;

    // Reusable Device Prefill State & Suffix Graph Exec (512 tokens)
    void* d_prefill_state_ = nullptr; // DevicePrefillState
    hipGraphExec_t suffix_graph_exec_ = nullptr;

    // Sampling state
    mutable std::vector<float> host_logits_;
    mutable std::vector<float> logits_scratch_;
    mutable std::vector<std::pair<float, std::uint32_t>> candidates_buf_;
    mutable std::mt19937 rng_{42};

    std::unordered_map<SnapshotId, SnapshotRecord> snapshots_;
    const SnapshotBacking* active_snapshot_backing_ = nullptr;
    SnapshotId next_snapshot_id_ = 1;
    std::uint64_t snapshot_use_clock_ = 0;
    std::size_t snapshot_bytes_ = 0;
    std::size_t last_hidden_offset_ = 0;
    bool last_hidden_valid_ = false;
    bool snapshot_state_loaded_ = false;
    std::size_t snapshot_cow_events_ = 0;
    std::size_t snapshot_cow_bytes_ = 0;

    void allocate_resources();
    void free_resources();
    void invalidate_runtime_state_cache() noexcept {
        reusable_context_.mark_not_resident();
        active_snapshot_backing_ = nullptr;
        snapshot_state_loaded_ = false;
    }
};

} // namespace miinfer::prefill_v2
