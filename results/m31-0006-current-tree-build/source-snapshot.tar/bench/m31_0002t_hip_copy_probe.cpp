#include <hip/hip_runtime.h>

#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <vector>

int main(int argc, char** argv) {
    if (argc != 2) {
        std::fprintf(stderr, "usage: m31-0002t-hip-copy-probe PCI_BDF\n");
        return 2;
    }

    if (hipInit(0) != hipSuccess) {
        std::fprintf(stderr, "hipInit failed\n");
        return 1;
    }

    int device = -1;
    auto status = hipDeviceGetByPCIBusId(&device, argv[1]);
    if (status != hipSuccess) {
        std::fprintf(stderr, "PCI device %s not found: %s\n", argv[1], hipGetErrorString(status));
        return 1;
    }

    hipDeviceProp_t properties{};
    status = hipGetDeviceProperties(&properties, device);
    if (status != hipSuccess) {
        std::fprintf(stderr, "hipGetDeviceProperties failed: %s\n", hipGetErrorString(status));
        return 1;
    }

    char pci_bus_id[32]{};
    status = hipDeviceGetPCIBusId(pci_bus_id, sizeof(pci_bus_id), device);
    if (status != hipSuccess || std::strcmp(pci_bus_id, argv[1]) != 0
        || std::strncmp(properties.gcnArchName, "gfx906", 6) != 0) {
        std::fprintf(stderr, "device identity mismatch: requested=%s actual=%s arch=%s\n",
                     argv[1], pci_bus_id, properties.gcnArchName);
        return 1;
    }
    if (hipSetDevice(device) != hipSuccess) {
        std::fprintf(stderr, "hipSetDevice failed for %s\n", pci_bus_id);
        return 1;
    }

    std::vector<std::uint8_t> host(4096);
    for (std::size_t i = 0; i < host.size(); ++i) host[i] = static_cast<std::uint8_t>(i * 37u);
    std::vector<std::uint8_t> copied(host.size());
    void* device_buffer = nullptr;
    status = hipMalloc(&device_buffer, host.size());
    if (status == hipSuccess) status = hipMemcpy(device_buffer, host.data(), host.size(), hipMemcpyHostToDevice);
    if (status == hipSuccess) status = hipMemcpy(copied.data(), device_buffer, host.size(), hipMemcpyDeviceToHost);
    if (device_buffer) {
        const auto free_status = hipFree(device_buffer);
        if (status == hipSuccess) status = free_status;
    }
    if (status != hipSuccess) {
        std::fprintf(stderr, "H2D/D2H verification failed on %s: %s\n",
                     pci_bus_id, hipGetErrorString(status));
        return 1;
    }
    if (copied != host) {
        std::fprintf(stderr, "H2D/D2H data mismatch on %s\n", pci_bus_id);
        return 1;
    }

    std::printf("PASS arch=%s pci=%s bytes=%zu H2D+D2H verified\n",
                properties.gcnArchName, pci_bus_id, host.size());
    return 0;
}
