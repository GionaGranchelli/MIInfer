#include "miinfer/kquant_wave_layout.hpp"
#include <cstring>
#include <stdexcept>
#include <cmath>
#include <array>
#include <algorithm>
#include <thread>
#include <vector>
#include <type_traits>

namespace {

inline float half_to_float(__half h) {
    #if defined(__HIP_PLATFORM_AMD__) || defined(__HIPCC__)
        return __half2float(h);
    #else
        // Host conversion using bit pattern
        std::uint16_t bits;
        std::memcpy(&bits, &h, sizeof(bits));
        const std::uint32_t sign = (static_cast<std::uint32_t>(bits & 0x8000U)) << 16U;
        const std::uint32_t exponent = (bits >> 10U) & 0x1fU;
        const std::uint32_t fraction = bits & 0x03ffU;
        std::uint32_t value = sign;
        if (exponent == 0) {
            if (fraction != 0) {
                std::uint32_t normalized = fraction;
                std::uint32_t exp = 0;
                while ((normalized & 0x0400U) == 0) {
                    normalized <<= 1U;
                    ++exp;
                }
                normalized &= 0x03ffU;
                value |= (127U - 15U - exp + 1U) << 23U;
                value |= normalized << 13U;
            }
        } else if (exponent == 0x1fU) {
            value |= 0x7f800000U | (fraction << 13U);
        } else {
            value |= (exponent + (127U - 15U)) << 23U;
            value |= fraction << 13U;
        }
        float res;
        std::memcpy(&res, &value, sizeof(res));
        return res;
    #endif
}

std::int8_t signed_q6_canonical(const miinfer::Q6KDeviceBlock& block, std::size_t index) noexcept {
    const std::size_t group = index / 128;
    const std::size_t lane = index % 128;
    const std::size_t quarter = lane / 32;
    const std::size_t in_quarter = lane % 32;
    const std::size_t low_index = group * 64 + in_quarter
                                  + (quarter == 1 || quarter == 3 ? 32 : 0);
    const std::size_t high_index = group * 32 + in_quarter;
    const std::uint8_t low = quarter < 2
                                 ? block.ql[low_index] & 0x0fU
                                 : block.ql[low_index] >> 4U;
    const std::uint8_t high = static_cast<std::uint8_t>(
        (block.qh[high_index] >> (2U * static_cast<unsigned>(quarter))) & 0x03U);
    return static_cast<std::int8_t>(static_cast<int>(low | (high << 4U)) - 32);
}

template <typename Block>
std::uint8_t affine_q_canonical(const Block& block, std::size_t index) noexcept {
    const std::size_t group = index / 32;
    const std::size_t in_group = index % 32;
    const std::size_t pair = group / 2;
    const std::size_t part = group % 2;
    const std::size_t half = in_group / 16;
    const std::size_t in_half = in_group % 16;
    const std::size_t byte = pair * 32 + (in_half / 4) * 4 + (half ? 16 : 0) + in_half % 4;
    const std::uint8_t* ql = nullptr;
    if constexpr (std::is_same_v<Block, miinfer::Q5KDeviceBlock>) ql = block.ql;
    else ql = block.qs;
    std::uint8_t value = static_cast<std::uint8_t>((ql[byte] >> (4 * part)) & 0x0fU);
    if constexpr (std::is_same_v<Block, miinfer::Q5KDeviceBlock>) {
        const std::size_t high_index = in_half + (half ? 16 : 0);
        value = static_cast<std::uint8_t>(value | (((block.qh[high_index] >> (2 * pair + part)) & 1U) << 4));
    }
    return value;
}

template <typename Block>
void decode_affine_scale_min(const Block& block, std::size_t group,
                             std::uint8_t& scale, std::uint8_t& minimum) noexcept {
    if (group < 4) {
        scale = block.scales[group] & 63U;
        minimum = block.scales[group + 4] & 63U;
    } else {
        scale = static_cast<std::uint8_t>((block.scales[group + 4] & 15U)
                                           | ((block.scales[group - 4] >> 6U) << 4U));
        minimum = static_cast<std::uint8_t>((block.scales[group + 4] >> 4U)
                                             | ((block.scales[group] >> 6U) << 4U));
    }
}

} // namespace

std::vector<Q4KWaveTile> pack_q4k_wave_tensor(const miinfer::GgufTensor& tensor) {
    if (tensor.type != miinfer::GgufTensorType::q4_k ||
        tensor.dimensions.size() != 2 ||
        tensor.data == nullptr)
        throw std::runtime_error("pack_q4k_wave_tensor requires 2D Q4_K tensor: " + tensor.name);
    const std::uint64_t columns = tensor.dimensions[0];
    const std::uint64_t rows = tensor.dimensions[1];
    if (columns % 1024 != 0 || rows % 2 != 0)
        throw std::runtime_error("pack_q4k_wave_tensor requires columns % 1024 == 0 and rows % 2 == 0: " + tensor.name);
    const std::size_t blocks = columns / 256;
    const std::size_t tiles_per_row = columns / 1024;
    if (tensor.byte_size != rows * blocks * sizeof(miinfer::Q4KDeviceBlock))
        throw std::runtime_error("pack_q4k_wave_tensor byte size mismatch: " + tensor.name);

    const auto* source = reinterpret_cast<const miinfer::Q4KDeviceBlock*>(tensor.data);
    std::vector<Q4KWaveTile> native(rows * tiles_per_row);

    const auto pack_range = [&](std::size_t start_row, std::size_t end_row) {
        for (std::size_t row = start_row; row < end_row; ++row) {
            for (std::size_t block = 0; block < blocks; ++block) {
                auto& tile = native[row * tiles_per_row + block / 4];
                const auto& src = source[row * blocks + block];
                auto& m = tile.metadata[block % 4];
                m.d = src.d; m.dmin = src.dmin;
                for (int g = 0; g < 8; ++g) {
                    m.scales[g] = g < 4 ? src.scales[g] & 63 :
                        (src.scales[g + 4] & 15) | ((src.scales[g - 4] >> 6) << 4);
                    m.minimums[g] = g < 4 ? src.scales[g + 4] & 63 :
                        (src.scales[g + 4] >> 4) | ((src.scales[g] >> 6) << 4);
                }
                std::uint8_t reconstructed[12]{};
                for (int g = 0; g < 4; ++g) {
                    reconstructed[g] = m.scales[g] | ((m.scales[g+4] >> 4) << 6);
                    reconstructed[g+4] = m.minimums[g] | ((m.minimums[g+4] >> 4) << 6);
                    reconstructed[g+8] = (m.scales[g+4] & 15) | ((m.minimums[g+4] & 15) << 4);
                }
                if (std::memcmp(reconstructed, src.scales, 12) ||
                    std::memcmp(&m.d, &src.d, sizeof(__half)) ||
                    std::memcmp(&m.dmin, &src.dmin, sizeof(__half)))
                    throw std::runtime_error("native Q4K metadata conversion mismatch: " + tensor.name);
                for (int i = 0; i < 16; ++i) for (int plane = 0; plane < 2; ++plane) {
                    const int offset = (i / 4) * 32 + (i % 4) * 4 + plane * 16;
                    std::memcpy(&tile.words[plane][(block % 4)*16+i], src.qs + offset, 4);
                }
                // Validate payload byte independently for row 0 only
                if (row == 0) {
                    for (int byte = 0; byte < 128; ++byte) {
                        const int i = (byte / 32)*4 + (byte % 16)/4;
                        const auto word = tile.words[(byte % 32)/16][(block % 4)*16+i];
                        if (((word >> (8*(byte%4))) & 255) != src.qs[byte])
                            throw std::runtime_error("native Q4K payload conversion mismatch: " + tensor.name);
                    }
                }
            }
        }
    };

    const unsigned int hw = std::thread::hardware_concurrency();
    const unsigned int num_threads = (rows > 1024 && hw > 1) ? std::min(48u, hw) : 1u;
    if (num_threads == 1) {
        pack_range(0, rows);
    } else {
        std::vector<std::thread> workers;
        workers.reserve(num_threads);
        const std::size_t chunk = (rows + num_threads - 1) / num_threads;
        for (unsigned int t = 0; t < num_threads; ++t) {
            const std::size_t start = t * chunk;
            const std::size_t end = std::min(rows, start + chunk);
            if (start >= end) break;
            workers.emplace_back(pack_range, start, end);
        }
        for (auto& w : workers) w.join();
    }
    return native;
}

std::vector<Q4KWaveTile> pack_q4k_wave_down(const miinfer::GgufTensor& tensor) {
    if (tensor.dimensions != std::vector<std::uint64_t>{17408, 5120})
        throw std::runtime_error("native Q4K Down requires Q4_K [17408,5120]");
    return pack_q4k_wave_tensor(tensor);
}

std::vector<Q4KWaveSwigluFusedTile> pack_q4k_wave_swiglu_fused(
    const miinfer::GgufTensor& gate,
    const miinfer::GgufTensor& up) {
    if (gate.dimensions != up.dimensions || gate.type != up.type ||
        gate.type != miinfer::GgufTensorType::q4_k) {
        throw std::runtime_error("pack_q4k_wave_swiglu_fused requires matching 2D Q4_K tensors: " + gate.name);
    }
    const auto packed_gate = pack_q4k_wave_tensor(gate);
    const auto packed_up = pack_q4k_wave_tensor(up);
    if (packed_gate.size() != packed_up.size()) {
        throw std::runtime_error("pack_q4k_wave_swiglu_fused tile count mismatch: " + gate.name);
    }

    const std::size_t total_tiles = packed_gate.size();
    std::vector<Q4KWaveSwigluFusedTile> fused(total_tiles);

    const auto fuse_range = [&](std::size_t start, std::size_t end) {
        for (std::size_t i = start; i < end; ++i) {
            auto& dst = fused[i];
            const auto& g = packed_gate[i];
            const auto& u = packed_up[i];
            for (int lane = 0; lane < 64; ++lane) {
                dst.words_p0[lane] = static_cast<std::uint64_t>(g.words[0][lane]) |
                                     (static_cast<std::uint64_t>(u.words[0][lane]) << 32);
                dst.words_p1[lane] = static_cast<std::uint64_t>(g.words[1][lane]) |
                                     (static_cast<std::uint64_t>(u.words[1][lane]) << 32);
            }
            for (int b = 0; b < 4; ++b) {
                dst.metadata_gate[b] = g.metadata[b];
                dst.metadata_up[b] = u.metadata[b];
            }
            std::memset(dst.padding, 0, sizeof(dst.padding));
        }
    };

    const unsigned int hw = std::thread::hardware_concurrency();
    const unsigned int num_threads = (total_tiles > 1024 && hw > 1) ? std::min(48u, hw) : 1u;
    if (num_threads == 1) {
        fuse_range(0, total_tiles);
    } else {
        std::vector<std::thread> workers;
        workers.reserve(num_threads);
        const std::size_t chunk = (total_tiles + num_threads - 1) / num_threads;
        for (unsigned int t = 0; t < num_threads; ++t) {
            const std::size_t start = t * chunk;
            const std::size_t end = std::min(total_tiles, start + chunk);
            if (start >= end) break;
            workers.emplace_back(fuse_range, start, end);
        }
        for (auto& w : workers) w.join();
    }

    return fused;
}

std::vector<Q5KWaveTile> pack_q5k_wave_tensor(const miinfer::GgufTensor& tensor) {
    if (tensor.type != miinfer::GgufTensorType::q5_k ||
        tensor.dimensions.size() != 2 ||
        tensor.data == nullptr)
        throw std::runtime_error("pack_q5k_wave_tensor requires 2D Q5_K tensor: " + tensor.name);
    const std::uint64_t columns = tensor.dimensions[0];
    const std::uint64_t rows = tensor.dimensions[1];
    if (columns % 1024 != 0 || rows % 2 != 0)
        throw std::runtime_error("pack_q5k_wave_tensor requires columns % 1024 == 0 and rows % 2 == 0: " + tensor.name);
    const std::size_t blocks = columns / 256;
    const std::size_t tiles_per_row = columns / 1024;
    if (tensor.byte_size != rows * blocks * sizeof(miinfer::Q5KDeviceBlock))
        throw std::runtime_error("pack_q5k_wave_tensor byte size mismatch: " + tensor.name);

    const auto* source = reinterpret_cast<const miinfer::Q5KDeviceBlock*>(tensor.data);
    std::vector<Q5KWaveTile> native(rows * tiles_per_row);

    const auto pack_range = [&](std::size_t start_row, std::size_t end_row) {
        for (std::size_t row = start_row; row < end_row; ++row) {
            for (std::size_t block = 0; block < blocks; ++block) {
                auto& tile = native[row * tiles_per_row + block / 4];
                const auto& src = source[row * blocks + block];
                auto& m = tile.metadata[block % 4];
                m.d = src.d; m.dmin = src.dmin;
                for (int g = 0; g < 8; ++g) {
                    m.scales[g] = g < 4 ? src.scales[g] & 63 :
                        (src.scales[g + 4] & 15) | ((src.scales[g - 4] >> 6) << 4);
                    m.minimums[g] = g < 4 ? src.scales[g + 4] & 63 :
                        (src.scales[g + 4] >> 4) | ((src.scales[g] >> 6) << 4);
                }
                std::uint8_t reconstructed[12]{};
                for (int g = 0; g < 4; ++g) {
                    reconstructed[g] = m.scales[g] | ((m.scales[g+4] >> 4) << 6);
                    reconstructed[g+4] = m.minimums[g] | ((m.minimums[g+4] >> 4) << 6);
                    reconstructed[g+8] = (m.scales[g+4] & 15) | ((m.minimums[g+4] & 15) << 4);
                }
                if (std::memcmp(reconstructed, src.scales, 12) ||
                    std::memcmp(&m.d, &src.d, sizeof(__half)) ||
                    std::memcmp(&m.dmin, &src.dmin, sizeof(__half)))
                    throw std::runtime_error("native Q5K metadata conversion mismatch: " + tensor.name);

                // Pack low nibble planes (same structure as Q4_K)
                for (int i = 0; i < 16; ++i) for (int plane = 0; plane < 2; ++plane) {
                    const int offset = (i / 4) * 32 + (i % 4) * 4 + plane * 16;
                    std::memcpy(&tile.words[plane][(block % 4)*16+i], src.ql + offset, 4);
                }

                // Pack high 5th bit plane into tile.qh
                for (int i = 0; i < 16; ++i) {
                    const int lane = (block % 4) * 16 + i;
                    const int pair = i / 4;
                    const int sub = i % 4;
                    std::uint32_t packed_qh = 0;
                    for (int j = 0; j < 4; ++j) {
                        const int idx0 = 4 * sub + j;
                        const int idx1 = 16 + 4 * sub + j;
                        const std::uint32_t h0_p0 = (src.qh[idx0] >> (2 * pair)) & 1;
                        const std::uint32_t h0_p1 = (src.qh[idx0] >> (2 * pair + 1)) & 1;
                        const std::uint32_t h1_p0 = (src.qh[idx1] >> (2 * pair)) & 1;
                        const std::uint32_t h1_p1 = (src.qh[idx1] >> (2 * pair + 1)) & 1;
                        const std::uint32_t byte_val = h0_p0 | (h0_p1 << 1) | (h1_p0 << 2) | (h1_p1 << 3);
                        packed_qh |= (byte_val << (8 * j));
                    }
                    tile.qh[lane] = packed_qh;
                }

                // Independent verification: reconstruct src.ql and src.qh for row 0 only
                if (row == 0) {
                    for (int byte = 0; byte < 128; ++byte) {
                        const int i = (byte / 32)*4 + (byte % 16)/4;
                        const auto word = tile.words[(byte % 32)/16][(block % 4)*16+i];
                        if (((word >> (8*(byte%4))) & 255) != src.ql[byte])
                            throw std::runtime_error("native Q5K payload ql conversion mismatch: " + tensor.name);
                    }

                    std::uint8_t reconstructed_qh[32]{};
                    for (int idx = 0; idx < 32; ++idx) {
                        const int plane = idx / 16;
                        const int in_p = idx % 16;
                        const int sub = in_p / 4;
                        const int j = in_p % 4;
                        std::uint8_t byte_val = 0;
                        for (int pair = 0; pair < 4; ++pair) {
                            const int i = pair * 4 + sub;
                            const int lane = (block % 4) * 16 + i;
                            const std::uint32_t h = (tile.qh[lane] >> (8 * j)) & 0xff;
                            if (plane == 0) {
                                const std::uint8_t p0 = h & 1;
                                const std::uint8_t p1 = (h >> 1) & 1;
                                byte_val |= (p0 << (2 * pair)) | (p1 << (2 * pair + 1));
                            } else {
                                const std::uint8_t p0 = (h >> 2) & 1;
                                const std::uint8_t p1 = (h >> 3) & 1;
                                byte_val |= (p0 << (2 * pair)) | (p1 << (2 * pair + 1));
                            }
                        }
                        reconstructed_qh[idx] = byte_val;
                    }
                    if (std::memcmp(reconstructed_qh, src.qh, 32) != 0)
                        throw std::runtime_error("native Q5K payload qh conversion mismatch: " + tensor.name);
                }
            }
        }
    };

    const unsigned int hw = std::thread::hardware_concurrency();
    const unsigned int num_threads = (rows > 1024 && hw > 1) ? std::min(48u, hw) : 1u;
    if (num_threads == 1) {
        pack_range(0, rows);
    } else {
        std::vector<std::thread> workers;
        workers.reserve(num_threads);
        const std::size_t chunk = (rows + num_threads - 1) / num_threads;
        for (unsigned int t = 0; t < num_threads; ++t) {
            const std::size_t start = t * chunk;
            const std::size_t end = std::min(rows, start + chunk);
            if (start >= end) break;
            workers.emplace_back(pack_range, start, end);
        }
        for (auto& w : workers) w.join();
    }
    return native;
}

std::vector<Q6KWaveTile> pack_q6k_wave_tensor(const miinfer::GgufTensor& tensor) {
    if (tensor.type != miinfer::GgufTensorType::q6_k ||
        tensor.dimensions.size() != 2 ||
        tensor.data == nullptr)
        throw std::runtime_error("pack_q6k_wave_tensor requires 2D Q6_K tensor: " + tensor.name);
    const std::uint64_t columns = tensor.dimensions[0];
    const std::uint64_t rows = tensor.dimensions[1];
    if (columns % 1024 != 0 || rows % 2 != 0)
        throw std::runtime_error("pack_q6k_wave_tensor requires columns % 1024 == 0 and rows % 2 == 0: " + tensor.name);
    const std::size_t blocks = columns / 256;
    const std::size_t tiles_per_row = columns / 1024;
    if (tensor.byte_size != rows * blocks * sizeof(miinfer::Q6KDeviceBlock))
        throw std::runtime_error("pack_q6k_wave_tensor byte size mismatch: " + tensor.name);

    const auto* source = reinterpret_cast<const miinfer::Q6KDeviceBlock*>(tensor.data);
    std::vector<Q6KWaveTile> native(rows * tiles_per_row);

    const auto pack_range = [&](std::size_t start_row, std::size_t end_row) {
        for (std::size_t row = start_row; row < end_row; ++row) {
            for (std::size_t block = 0; block < blocks; ++block) {
                auto& tile = native[row * tiles_per_row + block / 4];
                const auto& src = source[row * blocks + block];
                auto& m = tile.metadata[block % 4];
                m.d = src.d;
                std::memcpy(m.scales, src.scales, 16);
                m.pad[0] = 0;
                m.pad[1] = 0;

                if (std::memcmp(&m.d, &src.d, sizeof(__half)) ||
                    std::memcmp(m.scales, src.scales, 16))
                    throw std::runtime_error("native Q6K metadata conversion mismatch: " + tensor.name);

                // Pack words[0], words[1], and qh for the 16 lanes in this block
                for (int i = 0; i < 16; ++i) {
                    const int lane = (block % 4) * 16 + i;
                    const int pair = i / 4;
                    const int sub = i % 4;

                    std::uint32_t w0 = 0;
                    std::uint32_t w1 = 0;
                    std::uint32_t qh_val = 0;

                    const int group_0 = 2 * pair;
                    const int group_1 = 2 * pair + 1;

                    for (int j = 0; j < 4; ++j) {
                        const int elem_a0 = 32 * group_0 + 4 * sub + j;
                        const int elem_b0 = 32 * group_0 + 16 + 4 * sub + j;
                        const int elem_a1 = 32 * group_1 + 4 * sub + j;
                        const int elem_b1 = 32 * group_1 + 16 + 4 * sub + j;

                        auto extract_q6 = [&](int elem) {
                            const std::size_t g = elem / 128;
                            const std::size_t l = elem % 128;
                            const std::size_t q = l / 32;
                            const std::size_t in_q = l % 32;
                            const std::size_t low_idx = g * 64 + in_q + (q == 1 || q == 3 ? 32 : 0);
                            const std::size_t high_idx = g * 32 + in_q;
                            const std::uint8_t low = (q < 2) ? (src.ql[low_idx] & 0x0f) : (src.ql[low_idx] >> 4);
                            const std::uint8_t high = (src.qh[high_idx] >> (2 * q)) & 0x03;
                            return std::make_pair(low, high);
                        };

                        const auto [low_a0, high_a0] = extract_q6(elem_a0);
                        const auto [low_b0, high_b0] = extract_q6(elem_b0);
                        const auto [low_a1, high_a1] = extract_q6(elem_a1);
                        const auto [low_b1, high_b1] = extract_q6(elem_b1);

                        const std::uint32_t byte_w0 = low_a0 | (low_a1 << 4);
                        const std::uint32_t byte_w1 = low_b0 | (low_b1 << 4);
                        const std::uint32_t byte_qh = high_a0 | (high_b0 << 2) | (high_a1 << 4) | (high_b1 << 6);

                        w0 |= (byte_w0 << (8 * j));
                        w1 |= (byte_w1 << (8 * j));
                        qh_val |= (byte_qh << (8 * j));
                    }

                    tile.words[0][lane] = w0;
                    tile.words[1][lane] = w1;
                    tile.qh[lane] = qh_val;
                }

                // Independent verification: verify signed_q6 for row 0 only as sanity check
                if (row == 0) {
                    for (int elem = 0; elem < 256; ++elem) {
                        const int expected = signed_q6_canonical(src, elem);
                        const int q8_idx = elem / 32;
                        const int in_q8 = elem % 32;
                        const int pair = q8_idx / 2;
                        const int part = q8_idx % 2;
                        const int is_b = (in_q8 >= 16);
                        const int in_half = in_q8 % 16;
                        const int sub = in_half / 4;
                        const int j = in_half % 4;

                        const int i = pair * 4 + sub;
                        const int lane = (block % 4) * 16 + i;

                        std::uint32_t word = is_b ? tile.words[1][lane] : tile.words[0][lane];
                        std::uint32_t qh_word = tile.qh[lane];

                        std::uint32_t byte_w = (word >> (8 * j)) & 0xff;
                        std::uint32_t low = (part == 0) ? (byte_w & 0x0f) : (byte_w >> 4);

                        std::uint32_t byte_qh = (qh_word >> (8 * j)) & 0xff;
                        int shift = 0;
                        if (part == 0 && !is_b) shift = 0;
                        else if (part == 0 && is_b) shift = 2;
                        else if (part == 1 && !is_b) shift = 4;
                        else if (part == 1 && is_b) shift = 6;
                        std::uint32_t high = (byte_qh >> shift) & 0x03;

                        int actual = static_cast<int>(low | (high << 4)) - 32;
                        if (actual != expected)
                            throw std::runtime_error("native Q6K value mismatch at elem " + std::to_string(elem) + ": " + tensor.name);
                    }
                }
            }
        }
    };

    const unsigned int hw = std::thread::hardware_concurrency();
    const unsigned int num_threads = (rows > 1024 && hw > 1) ? std::min(48u, hw) : 1u;
    if (num_threads == 1) {
        pack_range(0, rows);
    } else {
        std::vector<std::thread> workers;
        workers.reserve(num_threads);
        const std::size_t chunk = (rows + num_threads - 1) / num_threads;
        for (unsigned int t = 0; t < num_threads; ++t) {
            const std::size_t start = t * chunk;
            const std::size_t end = std::min(rows, start + chunk);
            if (start >= end) break;
            workers.emplace_back(pack_range, start, end);
        }
        for (auto& w : workers) w.join();
    }
    return native;
}

std::vector<Q6KMmqTile> pack_q6k_mmq_tensor(const miinfer::GgufTensor& tensor) {
    if (tensor.type != miinfer::GgufTensorType::q6_k || tensor.dimensions.size() != 2
        || tensor.data == nullptr) {
        throw std::runtime_error("pack_q6k_mmq_tensor requires 2D Q6_K tensor: " + tensor.name);
    }
    const std::size_t columns = tensor.dimensions[0];
    const std::size_t rows = tensor.dimensions[1];
    if (columns % 128 != 0 || rows % 64 != 0) {
        throw std::runtime_error("pack_q6k_mmq_tensor requires columns % 128 == 0 and rows % 64 == 0: " + tensor.name);
    }
    const std::size_t blocks_per_row = columns / 256;
    if (tensor.byte_size != rows * blocks_per_row * sizeof(miinfer::Q6KDeviceBlock)) {
        throw std::runtime_error("pack_q6k_mmq_tensor byte size mismatch: " + tensor.name);
    }
    const auto* source = reinterpret_cast<const miinfer::Q6KDeviceBlock*>(tensor.data);
    const std::size_t k_tiles = columns / 128;
    std::vector<Q6KMmqTile> packed((rows / 64) * k_tiles);
    for (std::size_t row = 0; row < rows; ++row) {
        for (std::size_t tile_index = 0; tile_index < k_tiles; ++tile_index) {
            auto& tile = packed[(row / 64) * k_tiles + tile_index];
            const std::size_t local_row = row % 64;
            for (std::size_t slab = 0; slab < 4; ++slab) {
                const std::size_t global_slab = tile_index * 4 + slab;
                const auto& src = source[row * blocks_per_row + global_slab / 8];
                const std::size_t slab_in_block = global_slab % 8;
                std::uint32_t raw[4]{};
                std::uint64_t high = 0;
                for (std::size_t in = 0; in < 16; ++in) {
                    const int low = signed_q6_canonical(src, slab_in_block * 32 + in) + 32;
                    const int upper = signed_q6_canonical(src, slab_in_block * 32 + in + 16) + 32;
                    raw[in / 4] |= static_cast<std::uint32_t>((low & 0x0f) | ((upper & 0x0f) << 4))
                        << (8 * (in % 4));
                    high |= static_cast<std::uint64_t>((low >> 4) & 0x03) << (2 * in);
                    high |= static_cast<std::uint64_t>((upper >> 4) & 0x03) << (2 * (in + 16));
                }
                for (std::size_t word = 0; word < 4; ++word) tile.values[slab][local_row][word] = raw[word];
                tile.high[slab][local_row][0] = static_cast<std::uint32_t>(high);
                tile.high[slab][local_row][1] = static_cast<std::uint32_t>(high >> 32);
                const std::size_t scale = slab_in_block * 2;
                std::uint16_t d_bits = 0;
                std::memcpy(&d_bits, &src.d, sizeof(d_bits));
                tile.scale_d[slab][local_row] = static_cast<std::uint8_t>(src.scales[scale])
                    | (static_cast<std::uint32_t>(static_cast<std::uint8_t>(src.scales[scale + 1])) << 8)
                    | (static_cast<std::uint32_t>(d_bits) << 16);
            }
        }
    }
    return packed;
}

template <typename Tile, typename Block>
std::vector<Tile> pack_affine_mmq_tensor(const miinfer::GgufTensor& tensor,
                                         miinfer::GgufTensorType expected,
                                         const char* kind) {
    if (tensor.type != expected || tensor.dimensions.size() != 2 || tensor.data == nullptr) {
        throw std::runtime_error(std::string("pack_") + kind
                                 + "_mmq_tensor requires 2D tensor: " + tensor.name);
    }
    const std::size_t columns = tensor.dimensions[0];
    const std::size_t rows = tensor.dimensions[1];
    if (columns % 128 != 0 || rows % 64 != 0) {
        throw std::runtime_error(std::string("pack_") + kind
                                 + "_mmq_tensor requires columns % 128 == 0 and rows % 64 == 0: "
                                 + tensor.name);
    }
    const std::size_t blocks_per_row = columns / 256;
    if (tensor.byte_size != rows * blocks_per_row * sizeof(Block)) {
        throw std::runtime_error(std::string("pack_") + kind
                                 + "_mmq_tensor byte size mismatch: " + tensor.name);
    }
    const auto* source = reinterpret_cast<const Block*>(tensor.data);
    const std::size_t k_tiles = columns / 128;
    std::vector<Tile> packed((rows / 64) * k_tiles);
    for (std::size_t row = 0; row < rows; ++row) {
        for (std::size_t tile_index = 0; tile_index < k_tiles; ++tile_index) {
            auto& tile = packed[(row / 64) * k_tiles + tile_index];
            const std::size_t local_row = row % 64;
            for (std::size_t slab = 0; slab < 4; ++slab) {
                const std::size_t global_slab = tile_index * 4 + slab;
                const auto& src = source[row * blocks_per_row + global_slab / 8];
                const std::size_t slab_in_block = global_slab % 8;
                std::uint32_t raw[4]{};
                std::uint32_t high = 0;
                for (std::size_t in = 0; in < 16; ++in) {
                    const auto low = affine_q_canonical(src, slab_in_block * 32 + in);
                    const auto upper = affine_q_canonical(src, slab_in_block * 32 + in + 16);
                    raw[in / 4] |= static_cast<std::uint32_t>((low & 0x0fU) | ((upper & 0x0fU) << 4))
                        << (8 * (in % 4));
                    if constexpr (std::is_same_v<Block, miinfer::Q5KDeviceBlock>) {
                        high |= static_cast<std::uint32_t>((low >> 4) & 1U) << in;
                        high |= static_cast<std::uint32_t>((upper >> 4) & 1U) << (in + 16);
                    }
                }
                for (std::size_t word = 0; word < 4; ++word) tile.values[slab][local_row][word] = raw[word];
                tile.high[slab][local_row][0] = high;
                const std::size_t group = slab_in_block;
                std::uint8_t scale = 0, minimum = 0;
                decode_affine_scale_min(src, group, scale, minimum);
                std::uint16_t d_bits = 0, dmin_bits = 0;
                std::memcpy(&d_bits, &src.d, sizeof(d_bits));
                std::memcpy(&dmin_bits, &src.dmin, sizeof(dmin_bits));
                tile.scale_d[slab][local_row] = static_cast<std::uint32_t>(scale)
                    | (static_cast<std::uint32_t>(minimum) << 8)
                    | (static_cast<std::uint32_t>(d_bits) << 16);
                tile.dmin[slab][local_row] = dmin_bits;
            }
        }
    }
    return packed;
}

std::vector<Q4KMmqTile> pack_q4k_mmq_tensor(const miinfer::GgufTensor& tensor) {
    return pack_affine_mmq_tensor<Q4KMmqTile, miinfer::Q4KDeviceBlock>(
        tensor, miinfer::GgufTensorType::q4_k, "q4k");
}

std::vector<Q5KMmqTile> pack_q5k_mmq_tensor(const miinfer::GgufTensor& tensor) {
    return pack_affine_mmq_tensor<Q5KMmqTile, miinfer::Q5KDeviceBlock>(
        tensor, miinfer::GgufTensorType::q5_k, "q5k");
}

std::size_t mx_qs_stride(std::size_t packed_columns) {
    return packed_columns + (packed_columns % 128 == 0 ? 16 : 0);
}

template <typename Block, bool Q5>
std::vector<std::uint8_t> pack_mx_affine_repacked_tensor(
    const miinfer::GgufTensor& tensor, miinfer::GgufTensorType expected, const char* kind) {
    if (tensor.type != expected || tensor.dimensions.size() != 2 || tensor.data == nullptr) {
        throw std::runtime_error(std::string("pack_mx_") + kind
                                 + "_repacked_tensor requires 2D tensor: " + tensor.name);
    }
    const std::size_t columns = tensor.dimensions[0];
    const std::size_t rows = tensor.dimensions[1];
    if (columns % 256 != 0) {
        throw std::runtime_error(std::string("pack_mx_") + kind
                                 + "_repacked_tensor requires columns % 256 == 0: " + tensor.name);
    }
    const std::size_t blocks_per_row = columns / 256;
    if (tensor.byte_size != rows * blocks_per_row * sizeof(Block)) {
        throw std::runtime_error(std::string("pack_mx_") + kind
                                 + "_repacked_tensor byte size mismatch: " + tensor.name);
    }

    const auto* source = reinterpret_cast<const Block*>(tensor.data);
    const std::size_t n_sub = columns / 32;
    const std::size_t superblocks = (n_sub + 7) / 8;
    const std::size_t qs_stride = mx_qs_stride(columns / 2);
    const std::size_t qs_offset = rows * qs_stride;
    const std::size_t high_offset = qs_offset + (Q5 ? rows * n_sub * 4 : 0);
    const std::size_t scale_offset = high_offset + rows * superblocks * 12;
    std::vector<std::uint8_t> packed(scale_offset + rows * superblocks * 4);

    for (std::size_t row = 0; row < rows; ++row) {
        const auto* row_source = source + row * blocks_per_row;
        for (std::size_t sb = 0; sb < n_sub; ++sb) {
            const auto& block = row_source[sb / 8];
            const std::size_t in_block = sb % 8;
            const auto* q = [&] {
                if constexpr (Q5) return block.ql + 32 * (in_block / 2);
                else return block.qs + 32 * (in_block / 2);
            }();
            const int shift = static_cast<int>((in_block & 1) * 4);
            auto* lows = packed.data() + row * qs_stride + sb * 16;
            for (int i = 0; i < 16; ++i) {
                const auto low = static_cast<std::uint8_t>((q[i] >> shift) & 0x0fU);
                const auto upper = static_cast<std::uint8_t>((q[i + 16] >> shift) & 0x0fU);
                lows[i] = static_cast<std::uint8_t>(low | (upper << 4));
            }
            if constexpr (Q5) {
                const int high_bit = 2 * static_cast<int>(in_block / 2)
                                     + static_cast<int>(in_block & 1);
                std::uint32_t high = 0;
                for (int i = 0; i < 32; ++i) {
                    high |= static_cast<std::uint32_t>((block.qh[i] >> high_bit) & 1U) << i;
                }
                std::memcpy(packed.data() + qs_offset + (row * n_sub + sb) * 4,
                            &high, sizeof(high));
            }
            if (in_block == 0) {
                const std::size_t superblock = row * superblocks + sb / 8;
                std::memcpy(packed.data() + high_offset + superblock * 12,
                            block.scales, 12);
                std::memcpy(packed.data() + scale_offset + superblock * 4,
                            &block, 4);
            }
        }
    }
    return packed;
}

std::vector<std::uint8_t> pack_mx_q4k_repacked_tensor(const miinfer::GgufTensor& tensor) {
    return pack_mx_affine_repacked_tensor<miinfer::Q4KDeviceBlock, false>(
        tensor, miinfer::GgufTensorType::q4_k, "q4k");
}

std::vector<std::uint8_t> pack_mx_q5k_repacked_tensor(const miinfer::GgufTensor& tensor) {
    return pack_mx_affine_repacked_tensor<miinfer::Q5KDeviceBlock, true>(
        tensor, miinfer::GgufTensorType::q5_k, "q5k");
}

std::vector<std::uint8_t> pack_mx_q6k_repacked_tensor(const miinfer::GgufTensor& tensor) {
    if (tensor.type != miinfer::GgufTensorType::q6_k || tensor.dimensions.size() != 2
        || tensor.data == nullptr) {
        throw std::runtime_error("pack_mx_q6k_repacked_tensor requires 2D Q6_K tensor: " + tensor.name);
    }
    const std::size_t columns = tensor.dimensions[0];
    const std::size_t rows = tensor.dimensions[1];
    if (columns % 256 != 0) {
        throw std::runtime_error("pack_mx_q6k_repacked_tensor requires columns % 256 == 0: " + tensor.name);
    }
    const std::size_t blocks_per_row = columns / 256;
    if (tensor.byte_size != rows * blocks_per_row * sizeof(miinfer::Q6KDeviceBlock)) {
        throw std::runtime_error("pack_mx_q6k_repacked_tensor byte size mismatch: " + tensor.name);
    }
    const auto* source = reinterpret_cast<const miinfer::Q6KDeviceBlock*>(tensor.data);
    const std::size_t n_sub = columns / 32;
    const std::size_t superblocks = (n_sub + 7) / 8;
    const std::size_t qs_stride = mx_qs_stride(columns / 2);
    const std::size_t qs_offset = rows * qs_stride;
    const std::size_t high_offset = qs_offset + rows * n_sub * 8;
    const std::size_t scale_offset = high_offset + rows * n_sub * 2;
    std::vector<std::uint8_t> packed(scale_offset + rows * superblocks * 2);

    for (std::size_t row = 0; row < rows; ++row) {
        const auto* row_source = source + row * blocks_per_row;
        for (std::size_t sb = 0; sb < n_sub; ++sb) {
            const auto& block = row_source[sb / 8];
            const int in_block = static_cast<int>(sb & 7);
            std::uint8_t raw[32]{};
            for (int i = 0; i < 32; ++i) {
                const int value = in_block * 32 + i;
                const int half = value >> 7;
                const int local = value & 127;
                const auto* ql = block.ql + 64 * half;
                const auto* qh = block.qh + 32 * half;
                if (local < 32) {
                    raw[i] = static_cast<std::uint8_t>((ql[local] & 0x0fU)
                        | (((qh[local] >> 0) & 3U) << 4));
                } else if (local < 64) {
                    raw[i] = static_cast<std::uint8_t>((ql[local] & 0x0fU)
                        | (((qh[local - 32] >> 2) & 3U) << 4));
                } else if (local < 96) {
                    raw[i] = static_cast<std::uint8_t>((ql[local - 64] >> 4)
                        | (((qh[local - 64] >> 4) & 3U) << 4));
                } else {
                    raw[i] = static_cast<std::uint8_t>((ql[local - 64] >> 4)
                        | (((qh[local - 96] >> 6) & 3U) << 4));
                }
            }
            auto* lows = packed.data() + row * qs_stride + sb * 16;
            for (int i = 0; i < 16; ++i) {
                lows[i] = static_cast<std::uint8_t>((raw[i] & 0x0fU)
                    | ((raw[i + 16] & 0x0fU) << 4));
            }
            auto* highs = packed.data() + qs_offset + (row * n_sub + sb) * 8;
            for (int i = 0; i < 8; ++i) {
                const int base = (i & 3) * 4 + (i >> 2) * 16;
                highs[i] = static_cast<std::uint8_t>(((raw[base + 0] >> 4) << 0)
                    | ((raw[base + 1] >> 4) << 2)
                    | ((raw[base + 2] >> 4) << 4)
                    | ((raw[base + 3] >> 4) << 6));
            }
            const std::size_t index = row * n_sub + sb;
            packed[high_offset + index * 2 + 0] = static_cast<std::uint8_t>(block.scales[2 * in_block]);
            packed[high_offset + index * 2 + 1] = static_cast<std::uint8_t>(block.scales[2 * in_block + 1]);
            if (in_block == 0) {
                std::uint16_t d_bits = 0;
                std::memcpy(&d_bits, &block.d, sizeof(d_bits));
                std::memcpy(packed.data() + scale_offset + (row * superblocks + sb / 8) * 2,
                            &d_bits, sizeof(d_bits));
            }
        }
    }
    return packed;
}

void q4k_wave_tile_dequantize(const Q4KWaveTile& tile, float* output) {
    for (int block = 0; block < 4; ++block) {
        const auto& m = tile.metadata[block];
        const float d = half_to_float(m.d);
        const float dmin = half_to_float(m.dmin);

        for (int i = 0; i < 16; ++i) {
            const int lane = block * 16 + i;
            const int pair = i / 4;
            const int sub = i % 4;

            const std::uint32_t v0 = tile.words[0][lane];
            const std::uint32_t v1 = tile.words[1][lane];

            for (int part = 0; part < 2; ++part) {
                const int group = 2 * pair + part;
                const float scale = static_cast<float>(m.scales[group]);
                const float minimum = static_cast<float>(m.minimums[group]);

                for (int j = 0; j < 4; ++j) {
                    const int q0 = (v0 >> (4 * part + 8 * j)) & 0x0f;
                    const int q1 = (v1 >> (4 * part + 8 * j)) & 0x0f;

                    const int elem0 = block * 256 + 32 * group + 4 * sub + j;
                    const int elem1 = block * 256 + 32 * group + 16 + 4 * sub + j;

                    output[elem0] = d * scale * static_cast<float>(q0) - dmin * minimum;
                    output[elem1] = d * scale * static_cast<float>(q1) - dmin * minimum;
                }
            }
        }
    }
}

void q5k_wave_tile_dequantize(const Q5KWaveTile& tile, float* output) {
    for (int block = 0; block < 4; ++block) {
        const auto& m = tile.metadata[block];
        const float d = half_to_float(m.d);
        const float dmin = half_to_float(m.dmin);

        for (int i = 0; i < 16; ++i) {
            const int lane = block * 16 + i;
            const int pair = i / 4;
            const int sub = i % 4;

            const std::uint32_t v0 = tile.words[0][lane];
            const std::uint32_t v1 = tile.words[1][lane];
            const std::uint32_t h = tile.qh[lane];

            for (int part = 0; part < 2; ++part) {
                const int group = 2 * pair + part;
                const float scale = static_cast<float>(m.scales[group]);
                const float minimum = static_cast<float>(m.minimums[group]);

                for (int j = 0; j < 4; ++j) {
                    const int low0 = (v0 >> (4 * part + 8 * j)) & 0x0f;
                    const int low1 = (v1 >> (4 * part + 8 * j)) & 0x0f;

                    const std::uint32_t byte_h = (h >> (8 * j)) & 0xff;
                    const int h0 = (part == 0) ? (byte_h & 1) : ((byte_h >> 1) & 1);
                    const int h1 = (part == 0) ? ((byte_h >> 2) & 1) : ((byte_h >> 3) & 1);

                    const int q0 = low0 | (h0 << 4);
                    const int q1 = low1 | (h1 << 4);

                    const int elem0 = block * 256 + 32 * group + 4 * sub + j;
                    const int elem1 = block * 256 + 32 * group + 16 + 4 * sub + j;

                    output[elem0] = d * scale * static_cast<float>(q0) - dmin * minimum;
                    output[elem1] = d * scale * static_cast<float>(q1) - dmin * minimum;
                }
            }
        }
    }
}

void q6k_wave_tile_dequantize(const Q6KWaveTile& tile, float* output) {
    for (int block = 0; block < 4; ++block) {
        const auto& m = tile.metadata[block];
        const float d = half_to_float(m.d);

        for (int i = 0; i < 16; ++i) {
            const int lane = block * 16 + i;
            const int pair = i / 4;
            const int sub = i % 4;

            const std::uint32_t v0 = tile.words[0][lane];
            const std::uint32_t v1 = tile.words[1][lane];
            const std::uint32_t h = tile.qh[lane];

            for (int part = 0; part < 2; ++part) {
                const int group = 2 * pair + part;
                const float scale0 = static_cast<float>(m.scales[2 * group]);
                const float scale1 = static_cast<float>(m.scales[2 * group + 1]);

                for (int j = 0; j < 4; ++j) {
                    const int low0 = (v0 >> (4 * part + 8 * j)) & 0x0f;
                    const int low1 = (v1 >> (4 * part + 8 * j)) & 0x0f;

                    const std::uint32_t byte_h = (h >> (8 * j)) & 0xff;
                    const int shift0 = (part == 0) ? 0 : 4;
                    const int shift1 = (part == 0) ? 2 : 6;
                    const int h0 = (byte_h >> shift0) & 0x03;
                    const int h1 = (byte_h >> shift1) & 0x03;

                    const int q0 = static_cast<int>(low0 | (h0 << 4)) - 32;
                    const int q1 = static_cast<int>(low1 | (h1 << 4)) - 32;

                    const int elem0 = block * 256 + 32 * group + 4 * sub + j;
                    const int elem1 = block * 256 + 32 * group + 16 + 4 * sub + j;

                    output[elem0] = d * scale0 * static_cast<float>(q0);
                    output[elem1] = d * scale1 * static_cast<float>(q1);
                }
            }
        }
    }
}

void q4k_wave_gemv_reference(const Q4KWaveTile* w, const miinfer::Q8_1Block* x, float* y,
                             std::uint32_t rows, std::uint32_t columns) {
    const std::uint32_t num_tiles = columns / 1024;
    std::vector<float> tile_weights(1024);

    for (std::uint32_t r = 0; r < rows; ++r) {
        float sum = 0.0f;
        for (std::uint32_t t = 0; t < num_tiles; ++t) {
            const auto& tile = w[r * num_tiles + t];
            q4k_wave_tile_dequantize(tile, tile_weights.data());

            for (int k = 0; k < 1024; ++k) {
                const int q8_block_idx = (t * 1024 + k) / 32;
                const int q8_in_block = (t * 1024 + k) % 32;
                const auto& q8 = x[q8_block_idx];
                const float x_val = half_to_float(q8.d) * static_cast<float>(q8.qs[q8_in_block]);
                sum += tile_weights[k] * x_val;
            }
        }
        y[r] = sum;
    }
}

void q5k_wave_gemv_reference(const Q5KWaveTile* w, const miinfer::Q8_1Block* x, float* y,
                             std::uint32_t rows, std::uint32_t columns) {
    const std::uint32_t num_tiles = columns / 1024;
    std::vector<float> tile_weights(1024);

    for (std::uint32_t r = 0; r < rows; ++r) {
        float sum = 0.0f;
        for (std::uint32_t t = 0; t < num_tiles; ++t) {
            const auto& tile = w[r * num_tiles + t];
            q5k_wave_tile_dequantize(tile, tile_weights.data());

            for (int k = 0; k < 1024; ++k) {
                const int q8_block_idx = (t * 1024 + k) / 32;
                const int q8_in_block = (t * 1024 + k) % 32;
                const auto& q8 = x[q8_block_idx];
                const float x_val = half_to_float(q8.d) * static_cast<float>(q8.qs[q8_in_block]);
                sum += tile_weights[k] * x_val;
            }
        }
        y[r] = sum;
    }
}

void q6k_wave_gemv_reference(const Q6KWaveTile* w, const miinfer::Q8_1Block* x, float* y,
                             std::uint32_t rows, std::uint32_t columns) {
    const std::uint32_t num_tiles = columns / 1024;
    std::vector<float> tile_weights(1024);

    for (std::uint32_t r = 0; r < rows; ++r) {
        float sum = 0.0f;
        for (std::uint32_t t = 0; t < num_tiles; ++t) {
            const auto& tile = w[r * num_tiles + t];
            q6k_wave_tile_dequantize(tile, tile_weights.data());

            for (int k = 0; k < 1024; ++k) {
                const int q8_block_idx = (t * 1024 + k) / 32;
                const int q8_in_block = (t * 1024 + k) % 32;
                const auto& q8 = x[q8_block_idx];
                const float x_val = half_to_float(q8.d) * static_cast<float>(q8.qs[q8_in_block]);
                sum += tile_weights[k] * x_val;
            }
        }
        y[r] = sum;
    }
}

void q4k_wave_fused_gate_up_swiglu_reference(
    const Q4KWaveTile* w_gate,
    const Q4KWaveTile* w_up,
    const miinfer::Q8_1Block* x,
    float* y_activation,
    std::uint32_t rows,
    std::uint32_t columns) {
    std::vector<float> gate(rows);
    std::vector<float> up(rows);
    q4k_wave_gemv_reference(w_gate, x, gate.data(), rows, columns);
    q4k_wave_gemv_reference(w_up, x, up.data(), rows, columns);
    for (std::uint32_t r = 0; r < rows; ++r) {
        const float g = gate[r];
        const float u = up[r];
        const float silu_g = g / (1.0f + std::exp(-g));
        y_activation[r] = silu_g * u;
    }
}
