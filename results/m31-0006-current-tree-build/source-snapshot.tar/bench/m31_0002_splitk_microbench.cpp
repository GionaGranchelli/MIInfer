#include "miinfer/hip_check.hpp"
#include "miinfer/qwen3_gpu_primitives.hpp"
#include "miinfer/vector_add.hpp"

#include <hip/hip_runtime.h>

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

extern "C" void m31_fill_splitk_float(float*, std::size_t, std::uint32_t, float);
extern "C" void m31_fill_splitk_half(__half*, std::size_t, std::uint32_t);

namespace {

template <typename T>
struct DeviceBuffer {
    T* ptr = nullptr;
    std::size_t count = 0;
    explicit DeviceBuffer(std::size_t size) : count(size) {
        MIINFER_HIP_CHECK(hipMalloc(reinterpret_cast<void**>(&ptr), size * sizeof(T)));
    }
    ~DeviceBuffer() { if (ptr != nullptr) (void)hipFree(ptr); }
    DeviceBuffer(const DeviceBuffer&) = delete;
    DeviceBuffer& operator=(const DeviceBuffer&) = delete;
};

struct Timing {
    double mean_ms = 0.0;
    double min_ms = 0.0;
    double max_abs_error = 0.0;
    double rms_error = 0.0;
    bool finite = true;
};

Timing run_split(std::uint32_t split_count, std::uint32_t tokens,
                 std::uint32_t base, std::uint32_t capacity,
                 const float* q, const float* gate,
                 const __half* keys, const __half* values,
                 float* output, float* scratch, std::vector<float>& host_output,
                 const std::vector<float>* reference) {
    hipEvent_t start, stop;
    MIINFER_HIP_CHECK(hipEventCreate(&start));
    MIINFER_HIP_CHECK(hipEventCreate(&stop));
    constexpr int kSamples = 3;
    Timing timing;
    timing.min_ms = 1.0e30;
    for (int sample = -1; sample < kSamples; ++sample) {
        MIINFER_HIP_CHECK(hipEventRecord(start));
        miinfer::launch_qwen35_splitk_suffix_attention_quant(
            q, keys, values, nullptr, nullptr, nullptr, nullptr, gate, output,
            scratch, tokens, base, capacity, 24, 4, 256,
            1.0f / std::sqrt(256.0f), false, false, split_count);
        MIINFER_HIP_CHECK(hipEventRecord(stop));
        MIINFER_HIP_CHECK(hipEventSynchronize(stop));
        if (sample >= 0) {
            float ms = 0.0f;
            MIINFER_HIP_CHECK(hipEventElapsedTime(&ms, start, stop));
            timing.mean_ms += ms;
            timing.min_ms = std::min(timing.min_ms, static_cast<double>(ms));
        }
    }
    timing.mean_ms /= kSamples;
    MIINFER_HIP_CHECK(hipMemcpy(host_output.data(), output,
        host_output.size() * sizeof(float), hipMemcpyDeviceToHost));
    double sum_sq = 0.0;
    for (std::size_t i = 0; i < host_output.size(); ++i) {
        const float actual = host_output[i];
        if (!std::isfinite(actual)) timing.finite = false;
        if (reference != nullptr) {
            const double error = std::abs(static_cast<double>(actual) - (*reference)[i]);
            timing.max_abs_error = std::max(timing.max_abs_error, error);
            sum_sq += error * error;
        }
    }
    if (reference != nullptr) {
        timing.rms_error = std::sqrt(sum_sq / host_output.size());
    }
    (void)hipEventDestroy(start);
    (void)hipEventDestroy(stop);
    return timing;
}

} // namespace

int main(int argc, char** argv) {
    if (argc != 2 || (std::string(argv[1]) != "32K" && std::string(argv[1]) != "64K")) {
        std::cerr << "usage: miinfer-m31-0002-splitk-microbench 32K|64K\n";
        return 2;
    }
    try {
        const std::uint32_t prompt = std::string(argv[1]) == "32K" ? 32768 : 65536;
        constexpr std::uint32_t kTokens = 16;
        constexpr std::uint32_t kHeads = 24;
        constexpr std::uint32_t kDim = 256;
        constexpr std::uint32_t kSplits[] = {3, 4, 8, 16, 32};
        const std::uint32_t capacity = prompt + 256;
        const std::uint32_t base = prompt - kTokens;
        const std::size_t q_count = static_cast<std::size_t>(kTokens) * kHeads * kDim;
        const std::size_t kv_count = static_cast<std::size_t>(4) * capacity * kDim;
        const std::size_t gate_count = static_cast<std::size_t>(kTokens) * kHeads;
        const std::size_t scratch_floats = 32ULL * kTokens * kHeads * (kDim + 2);

        std::vector<float> host_output(q_count);

        DeviceBuffer<float> q(q_count);
        std::cout << "event=ALLOC_Q_READY\n" << std::flush;
        DeviceBuffer<float> gate(gate_count);
        std::cout << "event=ALLOC_GATE_READY\n" << std::flush;
        DeviceBuffer<float> output(q_count);
        std::cout << "event=ALLOC_OUTPUT_READY\n" << std::flush;
        DeviceBuffer<float> scratch(scratch_floats);
        std::cout << "event=ALLOC_SCRATCH_READY\n" << std::flush;
        DeviceBuffer<__half> keys(kv_count);
        std::cout << "event=ALLOC_KEYS_READY\n" << std::flush;
        DeviceBuffer<__half> values(kv_count);
        std::cout << "event=ALLOC_VALUES_READY\n" << std::flush;
        std::cout << "event=STANDARD_KERNEL_BEGIN\n" << std::flush;
        miinfer::launch_vector_add(q.ptr, q.ptr, output.ptr, q_count);
        MIINFER_HIP_CHECK(hipDeviceSynchronize());
        std::cout << "event=STANDARD_KERNEL_READY\n" << std::flush;
        std::cout << "event=DEVICE_INPUT_FILL_BEGIN\n" << std::flush;
        m31_fill_splitk_float(q.ptr, q_count, 17, 1.0f / 512.0f);
        MIINFER_HIP_CHECK(hipDeviceSynchronize());
        std::cout << "event=FILL_Q_READY\n" << std::flush;
        m31_fill_splitk_float(gate.ptr, gate_count, 31, 1.0f / 127.0f);
        MIINFER_HIP_CHECK(hipDeviceSynchronize());
        std::cout << "event=FILL_GATE_READY\n" << std::flush;
        m31_fill_splitk_half(keys.ptr, kv_count, 47);
        MIINFER_HIP_CHECK(hipDeviceSynchronize());
        std::cout << "event=FILL_KEYS_READY\n" << std::flush;
        m31_fill_splitk_half(values.ptr, kv_count, 71);
        MIINFER_HIP_CHECK(hipDeviceSynchronize());
        std::cout << "event=DEVICE_INPUT_FILL_READY\n" << std::flush;

        std::cout << "benchmark=M31-0002-splitk-microbench\ncontext=" << argv[1]
                  << "\nprompt_tokens=" << prompt << "\nquery_tokens=" << kTokens
                  << "\nposition_range=" << base << '-' << (prompt - 1)
                  << "\nkv_capacity=" << capacity << "\nkv_bytes="
                  << 2ULL * kv_count * sizeof(__half) << "\nscratch_bytes_at_32="
                  << scratch_floats * sizeof(float) << '\n' << std::flush;

        std::vector<float> reference;
        const auto reference_timing = run_split(32, kTokens, base, capacity,
            q.ptr, gate.ptr, keys.ptr, values.ptr, output.ptr, scratch.ptr,
            host_output, nullptr);
        reference = host_output;
        std::cout << std::fixed << std::setprecision(4)
                  << "event=REFERENCE_READY split=32 mean_ms=" << reference_timing.mean_ms
                  << '\n' << std::flush;
        for (const auto splits : kSplits) {
            const auto result = run_split(splits, kTokens, base, capacity,
                q.ptr, gate.ptr, keys.ptr, values.ptr, output.ptr, scratch.ptr,
                host_output, splits == 32 ? nullptr : &reference);
            std::cout << std::fixed << std::setprecision(4)
                      << "split=" << splits
                      << " scratch_bytes=" << (static_cast<std::size_t>(splits) * kTokens * kHeads * (kDim + 2) * sizeof(float))
                      << " mean_ms=" << result.mean_ms
                      << " min_ms=" << result.min_ms
                      << " max_abs_error_vs_32=" << result.max_abs_error
                      << " rms_error_vs_32=" << result.rms_error
                      << " finite=" << (result.finite ? "PASS" : "FAIL") << '\n' << std::flush;
            if (!result.finite || (splits != 32 && result.max_abs_error > 5.0e-3)) {
                throw std::runtime_error("split-count output failed numerical comparison");
            }
        }
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "M31-0002 split-k microbench: FAIL: " << error.what() << '\n';
        return 1;
    }
}
