#include "miinfer/hip_check.hpp"
#include "miinfer/prefill_v2/constants.hpp"
#include "miinfer/prefill_v2/model.hpp"
#include "miinfer/qwen35_model.hpp"

#include <hip/hip_runtime.h>

#include <chrono>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

using namespace miinfer;
using namespace miinfer::prefill_v2;

namespace {

constexpr std::uint32_t kChunkTokens = 512;

std::vector<std::uint32_t> make_prompt(std::uint32_t count) {
    std::vector<std::uint32_t> tokens(count);
    std::uint32_t seed = 77;
    for (auto& token : tokens) {
        seed = seed * 1664525u + 1013904223u;
        token = seed % 151643u + 1;
    }
    return tokens;
}

} // namespace

int main(int argc, char** argv) {
    if (argc != 3 || (std::string(argv[2]) != "8K" &&
                      std::string(argv[2]) != "32K" && std::string(argv[2]) != "64K")) {
        std::cerr << "usage: miinfer-m31-0002-profiled-prefill MODEL.gguf 8K|32K|64K\n";
        return 2;
    }

    try {
        const std::string context = argv[2];
        const std::uint32_t prompt_tokens = context == "8K" ? 8192 : context == "32K" ? 32768 : 65536;
        const auto model_data = Qwen35Model::load(argv[1]);
        PrefillV2Model model(model_data, prompt_tokens + 256, true);
        const auto prompt = make_prompt(prompt_tokens);

        GenerateOptions clean_options;
        clean_options.max_new_tokens = 1;
        clean_options.reset_state_before = true;
        clean_options.use_hip_graph = true;
        clean_options.temperature = 0.0f;
        clean_options.top_p = 1.0f;
        clean_options.top_k = 1;
        clean_options.stop_token_ids.clear();

        std::cout << "benchmark=M31-0002-profiled-prefill\ncontext=" << context << '\n'
                  << "prompt_tokens=" << prompt_tokens
                  << "\nchunk_tokens=" << kChunkTokens
                  << "\nmodel_vram_bytes=" << model.total_vram_bytes() << '\n' << std::flush;

        const auto clean = model.generate(prompt, clean_options);
        std::cout << std::fixed << std::setprecision(3)
                  << "clean_prefill_ms=" << clean.prefill_ms
                  << "\nclean_ttft_ms=" << clean.ttft_ms
                  << "\nclean_generated_tokens=" << clean.generated_tokens.size() << '\n'
                  << std::flush;

        model.reset_state();
        std::uint32_t* d_tokens = nullptr;
        float* d_final_hidden = nullptr;
        MIINFER_HIP_CHECK(hipMalloc(reinterpret_cast<void**>(&d_tokens), kChunkTokens * sizeof(*d_tokens)));
        MIINFER_HIP_CHECK(hipMalloc(reinterpret_cast<void**>(&d_final_hidden),
                                    kChunkTokens * kHidden * sizeof(*d_final_hidden)));

        double upload_ms = 0.0;
        double embedding_ms = 0.0;
        double final_norm_ms = 0.0;
        double model_event_ms = 0.0;
        double gdn0_ms = 0.0, gdn1_ms = 0.0, gdn2_ms = 0.0, gqa_ms = 0.0;
        const auto profile_start = std::chrono::steady_clock::now();
        for (std::uint32_t base = 0; base < prompt_tokens; base += kChunkTokens) {
            const auto upload_start = std::chrono::steady_clock::now();
            MIINFER_HIP_CHECK(hipMemcpy(d_tokens, prompt.data() + base,
                                        kChunkTokens * sizeof(*d_tokens), hipMemcpyHostToDevice));
            upload_ms += std::chrono::duration<double, std::milli>(
                std::chrono::steady_clock::now() - upload_start).count();

            ModelProfileBreakdown breakdown;
            model.forward_profiled(d_tokens, base, kChunkTokens, d_final_hidden, breakdown);
            embedding_ms += breakdown.embedding_ms;
            final_norm_ms += breakdown.final_norm_ms;
            model_event_ms += breakdown.total_model_ms;
            for (const auto& block : breakdown.block_breakdowns) {
                gdn0_ms += block.gdn0_ms;
                gdn1_ms += block.gdn1_ms;
                gdn2_ms += block.gdn2_ms;
                gqa_ms += block.gqa3_ms;
            }
        }
        MIINFER_HIP_CHECK(hipDeviceSynchronize());
        const double profile_wall_ms = std::chrono::duration<double, std::milli>(
            std::chrono::steady_clock::now() - profile_start).count();
        MIINFER_HIP_CHECK(hipFree(d_final_hidden));
        MIINFER_HIP_CHECK(hipFree(d_tokens));

        const double layers_ms = gdn0_ms + gdn1_ms + gdn2_ms + gqa_ms;
        const double component_ms = embedding_ms + layers_ms + final_norm_ms;
        std::cout << "profile_wall_ms=" << profile_wall_ms
                  << "\nprofile_input_upload_ms=" << upload_ms
                  << "\nprofile_model_event_ms=" << model_event_ms
                  << "\nprofile_embedding_ms=" << embedding_ms
                  << "\nprofile_gdn0_ms=" << gdn0_ms
                  << "\nprofile_gdn1_ms=" << gdn1_ms
                  << "\nprofile_gdn2_ms=" << gdn2_ms
                  << "\nprofile_gqa_ms=" << gqa_ms
                  << "\nprofile_final_norm_ms=" << final_norm_ms
                  << "\nprofile_component_sum_ms=" << component_ms
                  << "\nprofile_unattributed_wall_ms=" << profile_wall_ms - upload_ms - component_ms
                  << "\nprofile_vs_clean_prefill_ratio=" << profile_wall_ms / clean.prefill_ms
                  << "\ncomponent_vs_model_event_pct="
                  << (component_ms - model_event_ms) * 100.0 / model_event_ms
                  << '\n' << std::flush;
        return clean.generated_tokens.size() == 1 ? 0 : 1;
    } catch (const std::exception& error) {
        std::cerr << "M31-0002 profiled prefill: FAIL: " << error.what() << '\n';
        return 1;
    }
}
