#include <hip/hip_runtime.h>

#include <algorithm>
#include <cstddef>
#include <cstdio>
#include <vector>

int main() {
    auto check = [](hipError_t error, const char* label) {
        std::printf("%s: %d %s\n", label, static_cast<int>(error), hipGetErrorString(error));
        return error == hipSuccess;
    };

    if (!check(hipInit(0), "hipInit")) return 1;
    int count = 0;
    if (!check(hipGetDeviceCount(&count), "hipGetDeviceCount")) return 1;
    std::printf("device_count=%d\n", count);
    if (count == 0 || !check(hipSetDevice(0), "hipSetDevice")) return 1;

    hipDeviceProp_t properties{};
    if (!check(hipGetDeviceProperties(&properties, 0), "hipGetDeviceProperties")) return 1;
    std::printf("device=%s\n", properties.name);

    std::size_t free_bytes = 0;
    std::size_t total_bytes = 0;
    if (!check(hipMemGetInfo(&free_bytes, &total_bytes), "hipMemGetInfo")) return 1;
    std::printf("free=%zu total=%zu\n", free_bytes, total_bytes);

    void* early_device = nullptr;
    std::fprintf(stderr, "early_alloc\n");
    const auto early_alloc_error = hipMalloc(&early_device, 4096);
    std::fprintf(stderr, "early_copy\n");
    void* early_host = nullptr;
    const auto early_host_error = hipHostMalloc(&early_host, 4096);
    const auto early_copy_error = early_alloc_error == hipSuccess
        && early_host_error == hipSuccess
        ? hipMemcpy(early_device, early_host, 4096, hipMemcpyHostToDevice)
        : early_host_error != hipSuccess ? early_host_error : early_alloc_error;
    std::fprintf(stderr, "early_result alloc=%d host=%d copy=%d\n",
                 static_cast<int>(early_alloc_error), static_cast<int>(early_host_error),
                 static_cast<int>(early_copy_error));
    if (early_host) hipHostFree(early_host);
    if (early_device) hipFree(early_device);

    for (const std::size_t bytes : {std::size_t{4} * 1024,
                                    std::size_t{64} * 1024,
                                    std::size_t{1} * 1024 * 1024,
                                    std::size_t{64} * 1024 * 1024,
                                    std::size_t{128} * 1024 * 1024,
                                    std::size_t{144} * 1024 * 1024,
                                    std::size_t{150994944},
                                    std::size_t{256} * 1024 * 1024,
                                    std::size_t{1024} * 1024 * 1024}) {
        void* pointer = nullptr;
        const auto error = hipMalloc(&pointer, bytes);
        std::printf("hipMalloc bytes=%zu: %d %s\n",
                    bytes, static_cast<int>(error), hipGetErrorString(error));
        if (error == hipSuccess) {
            hipFree(pointer);
        }
        if (error != hipSuccess) return 2;
    }

    void* state = nullptr;
    void* history = nullptr;
    void* hidden = nullptr;
    void* embedding = nullptr;
    const auto state_error = hipMalloc(&state, 150994944);
    const auto history_error = hipMalloc(&history, 7864320);
    const auto hidden_error = hipMalloc(&hidden, 20480);
    const auto embedding_error = hipMalloc(&embedding, 715161600);
    std::vector<unsigned char> host_embedding(715161600);
    void* pinned_host = nullptr;
    const auto pinned_error = hipHostMalloc(&pinned_host, 4096);
    hipStream_t copy_stream = nullptr;
    const auto stream_error = hipStreamCreate(&copy_stream);
    const auto copy_error = pinned_error != hipSuccess ? pinned_error
        : stream_error == hipSuccess
        ? hipMemcpyAsync(embedding, pinned_host, 4096, hipMemcpyHostToDevice, copy_stream)
        : stream_error;
    if (copy_error == hipSuccess) hipStreamSynchronize(copy_stream);
    std::printf("sequence state: %d %s history: %d %s hidden: %d %s embedding: %d %s\n",
                static_cast<int>(state_error), hipGetErrorString(state_error),
                static_cast<int>(history_error), hipGetErrorString(history_error),
                static_cast<int>(hidden_error), hipGetErrorString(hidden_error),
                static_cast<int>(embedding_error), hipGetErrorString(embedding_error));
    std::printf("large_copy: %d %s\n", static_cast<int>(copy_error), hipGetErrorString(copy_error));
    if (state) hipFree(state);
    if (history) hipFree(history);
    if (hidden) hipFree(hidden);
    if (embedding) hipFree(embedding);
    if (copy_stream) hipStreamDestroy(copy_stream);
    if (pinned_host) hipHostFree(pinned_host);
    if (state_error != hipSuccess || history_error != hipSuccess
        || hidden_error != hipSuccess || embedding_error != hipSuccess || copy_error != hipSuccess) return 3;
    return 0;
}
