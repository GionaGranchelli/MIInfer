#include <hip/hip_runtime.h>

#include <array>
#include <cstdio>

int main() {
    if (hipInit(0) != hipSuccess) return 1;
    int count = 0;
    if (hipGetDeviceCount(&count) != hipSuccess || count == 0) return 2;
    if (hipSetDevice(0) != hipSuccess) return 3;

    constexpr std::array<std::size_t, 9> sizes{
        4 * 1024, 64 * 1024, 1 * 1024 * 1024, 64 * 1024 * 1024,
        128 * 1024 * 1024, 144 * 1024 * 1024, 150 * 1024 * 1024,
        256 * 1024 * 1024, 1ULL * 1024 * 1024 * 1024};
    for (const std::size_t bytes : sizes) {
        void* ptr = nullptr;
        const hipError_t error = hipMalloc(&ptr, bytes);
        std::printf("hipMalloc bytes=%zu status=%d message=%s\n", bytes,
                    static_cast<int>(error), hipGetErrorString(error));
        std::fflush(stdout);
        if (error != hipSuccess) return 4;
        const hipError_t free_error = hipFree(ptr);
        if (free_error != hipSuccess) return 5;
    }
    return 0;
}
