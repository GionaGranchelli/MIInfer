#include "m31_0002_prompt.hpp"

#include <array>
#include <cassert>

int main() {
    const auto prompt = m31_0002::make_prompt(8192, 77);
    constexpr std::array<std::uint32_t, 8> first{
        49216, 4770, 1080, 129452, 11663, 57238, 68535, 20228};
    assert(prompt.size() == 8192);
    for (std::size_t i = 0; i < first.size(); ++i) assert(prompt[i] == first[i]);
    assert(m31_0002::prompt_fingerprint(prompt) == 0xfa51ca776f59c7b6ULL);
}
