#pragma once

#include "miinfer/generation_contract.hpp"

#include <cstddef>
#include <cstdint>
#include <optional>
#include <string>
#include <string_view>
#include <vector>

namespace miinfer {

struct ChatToolCall {
    std::string id;
    std::string name;
    std::string arguments;
};

struct ChatTool {
    std::string name;
    std::string description;
    std::string parameters_json;
};

struct ChatMessage {
    std::string role;
    std::string content;
    std::optional<std::string> tool_call_id;
    std::vector<ChatToolCall> tool_calls;
};

struct OpenAiChatRequest {
    std::optional<std::string> model;
    std::vector<ChatMessage> messages;
    std::vector<ChatTool> tools;
    std::vector<std::string> stop;
    std::string tool_choice = "auto";
    bool stream = false;
    std::optional<std::size_t> max_tokens;
    float temperature = 0.7f;
    float top_p = 0.9f;
    std::uint32_t top_k = 40;
    float repetition_penalty = 1.15f;
    float frequency_penalty = 0.0f;
    float presence_penalty = 0.0f;
    std::size_t repeat_last_n = 256;
};

struct OpenAiParseResult {
    std::optional<OpenAiChatRequest> request;
    std::string error;
};

constexpr std::size_t kMaxOutputTokens = 65536;

struct OpenAiGeneratedToolCalls {
    std::vector<ChatToolCall> calls;
};

OpenAiParseResult parse_openai_chat_request(std::string_view body);
std::string_view openai_finish_reason(GenerationStopReason reason, bool has_tool_calls = false) noexcept;
std::string build_chatml(const OpenAiChatRequest& request);
OpenAiGeneratedToolCalls parse_generated_tool_calls(std::string_view text);

} // namespace miinfer
