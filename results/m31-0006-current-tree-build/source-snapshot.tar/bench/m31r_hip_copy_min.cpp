#include <hip/hip_runtime.h>

#include <cstdio>

int main() {
    if (hipInit(0) != hipSuccess) return 1;
    if (hipSetDevice(0) != hipSuccess) return 2;
    void* device = nullptr;
    unsigned char host[4096]{};
    const auto allocation = hipMalloc(&device, sizeof(host));
    const auto copy = allocation == hipSuccess
        ? hipMemcpy(device, host, sizeof(host), hipMemcpyHostToDevice)
        : allocation;
    std::fprintf(stderr, "alloc=%d copy=%d %s\n",
                 static_cast<int>(allocation), static_cast<int>(copy), hipGetErrorString(copy));
    if (device) hipFree(device);
    return copy == hipSuccess ? 0 : 3;
}
