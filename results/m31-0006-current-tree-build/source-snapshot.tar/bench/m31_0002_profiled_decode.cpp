#include "miinfer/prefill_v2/model.hpp"
#include "miinfer/qwen35_model.hpp"

#include <cstdint>
#include <chrono>
#include <iomanip>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

using namespace miinfer;
using namespace miinfer::prefill_v2;

namespace {

std::vector<std::uint32_t> make_prompt(std::uint32_t count) {
    std::vector<std::uint32_t> tokens(count);
    std::uint32_t seed = 77;
    for (auto& token : tokens) {
        seed = seed * 1664525u + 1013904223u;
        token = seed % 151643u + 1;
    }
    return tokens;
}

GenerateOptions greedy(std::size_t count, const std::string& call) {
    GenerateOptions options;
    options.max_new_tokens = count;
    options.reset_state_before = true;
    options.use_hip_graph = false;
    options.temperature = 0.0f;
    options.top_p = 1.0f;
    options.top_k = 1;
    options.repetition_penalty = 1.0f;
    options.stop_token_ids.clear();
    static constexpr std::uint32_t thresholds[] = {10, 25, 50, 75, 100};
    auto next = std::make_shared<std::size_t>(0);
    options.on_prefill_progress = [call, next](std::uint32_t done, std::uint32_t total) {
        while (*next < 5 && static_cast<std::uint64_t>(done) * 100
                >= static_cast<std::uint64_t>(total) * thresholds[*next]) {
            std::cout << "event=PREFILL_PROGRESS call=" << call << " percent="
                      << thresholds[*next] << " tokens=" << done << '/' << total << '\n' << std::flush;
            ++*next;
        }
    };
    auto first = std::make_shared<bool>(true);
    options.on_token = [call, first](std::uint32_t token) {
        if (*first) {
            std::cout << "event=PREFILL_END call=" << call << "\nevent=DECODE_BEGIN call="
                      << call << '\n';
            *first = false;
        }
        std::cout << "event=TOKEN call=" << call << " id=" << token << '\n' << std::flush;
        return true;
    };
    return options;
}

} // namespace

int main(int argc, char** argv) {
    if (argc != 3 || (std::string(argv[2]) != "8K" &&
                      std::string(argv[2]) != "32K" && std::string(argv[2]) != "64K")) {
        std::cerr << "usage: miinfer-m31-0002-profiled-decode MODEL.gguf 8K|32K|64K\n";
        return 2;
    }
    try {
        const std::string context = argv[2];
        const std::uint32_t prompt_size = context == "8K" ? 8192 : context == "32K" ? 32768 : 65536;
        const auto model_data = Qwen35Model::load(argv[1]);
        PrefillV2Model model(model_data, prompt_size + 256, true);
        const auto prompt = make_prompt(prompt_size);
        std::cout << "benchmark=M31-0002-profiled-decode\ncontext=" << context
                  << "\nprompt_tokens=" << prompt_size << "\nmodel_vram_bytes="
                  << model.total_vram_bytes() << '\n' << std::flush;

        const auto run_generation = [&](const std::string& name, std::size_t count) {
            const auto start = std::chrono::steady_clock::now();
            std::cout << "event=CALL_START call=" << name << "\nevent=PREFILL_BEGIN call="
                      << name << '\n' << std::flush;
            const auto result = model.generate(prompt, greedy(count, name));
            const double elapsed_ms = std::chrono::duration<double, std::milli>(
                std::chrono::steady_clock::now() - start).count();
            std::cout << "event=DECODE_END call=" << name << "\nevent=CALL_COMPLETE call="
                      << name << " elapsed_ms=" << std::fixed << std::setprecision(3)
                      << elapsed_ms << " tokens=" << result.generated_tokens.size() << '\n' << std::flush;
            return result;
        };
        const auto reference = run_generation("clean_reference", 2);
        if (reference.generated_tokens.size() != 2) throw std::runtime_error("reference decode did not return two tokens");
        if (reference.decode_ms <= 0.0) throw std::runtime_error("clean reference decode timing is unavailable");
        const auto prefix = run_generation("profile_prefix", 1);
        if (prefix.generated_tokens.size() != 1 || prefix.generated_tokens[0] != reference.generated_tokens[0]) {
            throw std::runtime_error("greedy prefix parity failed");
        }

        ModelDecodeProfileBreakdown profile;
        std::cout << "event=CALL_START call=profiled_decode\nevent=DECODE_BEGIN call=profiled_decode\n" << std::flush;
        const auto profile_start = std::chrono::steady_clock::now();
        const auto next = model.decode_step_profiled(
            prefix.generated_tokens[0], prompt_size, profile);
        const double profile_elapsed = std::chrono::duration<double, std::milli>(
            std::chrono::steady_clock::now() - profile_start).count();
        double recurrent_ms = 0.0;
        double attention_ms = 0.0;
        for (const auto& layer : profile.recurrent_layers) recurrent_ms += layer.total_layer_ms;
        for (const auto& layer : profile.attention_layers) attention_ms += layer.total_layer_ms;
        std::cout << std::fixed << std::setprecision(3)
                  << "expected_next_token=" << reference.generated_tokens[1]
                  << "\nprofiled_next_token=" << next
                  << "\noutput_parity=" << (next == reference.generated_tokens[1] ? "PASS" : "FAIL")
                  << "\nprofile_wall_ms=" << profile.wall_ms
                  << "\nprofile_call_elapsed_ms=" << profile_elapsed
                  << "\nclean_reference_decode_ms=" << reference.decode_ms
                  << "\nclean_reference_decode_tokens=" << reference.generated_tokens.size() - 1
                  << "\nprofile_to_clean_decode_ratio=" << profile.wall_ms / reference.decode_ms
                  << "\ndevice_timeline_ms=" << profile.device_timeline_ms
                  << "\nhost_to_device_ms=" << profile.host_to_device_ms
                  << "\nembedding_ms=" << profile.embedding_ms
                  << "\nrecurrent_layers_ms=" << recurrent_ms
                  << "\nattention_layers_ms=" << attention_ms
                  << "\nfinal_norm_ms=" << profile.final_norm_ms
                  << "\nlogits_ms=" << profile.logits_ms
                  << "\nargmax_ms=" << profile.argmax_ms
                  << "\ndevice_to_host_ms=" << profile.device_to_host_ms << '\n';
        for (std::size_t i = 0; i < profile.recurrent_layers.size(); ++i) {
            const auto& layer = profile.recurrent_layers[i];
            std::cout << "gdn_layer=" << i << " total_ms=" << layer.total_layer_ms
                      << " projection_ms=" << layer.qkv_gate_proj_ms
                      << " recurrence_ms=" << layer.gdn_step_ms
                      << " attention_norm_ms=" << layer.norm_beta_alpha_ms
                      << " ffn_ms=" << layer.ffn_gate_up_swiglu_ms + layer.ffn_down_residual_ms << '\n';
        }
        for (std::size_t i = 0; i < profile.attention_layers.size(); ++i) {
            const auto& layer = profile.attention_layers[i];
            std::cout << "gqa_layer=" << i << " total_ms=" << layer.total_layer_ms
                      << " qkv_ms=" << layer.qkv_proj_ms
                      << " attention_ms=" << layer.splitk_attention_ms
                      << " ffn_ms=" << layer.ffn_gate_up_swiglu_ms + layer.ffn_down_residual_ms << '\n';
        }
        return next == reference.generated_tokens[1] ? 0 : 1;
    } catch (const std::exception& error) {
        std::cerr << "M31-0002 profiled decode: FAIL: " << error.what() << '\n';
        return 1;
    }
}
