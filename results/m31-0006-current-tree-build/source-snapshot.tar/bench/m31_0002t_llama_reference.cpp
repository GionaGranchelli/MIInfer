#include "m31_0002_prompt.hpp"

#include <ggml-backend.h>
#include <llama.h>

#include <algorithm>
#include <chrono>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

namespace {

using Clock = std::chrono::steady_clock;

void event(std::ostream& out, const char* name, const Clock::time_point& start) {
    const auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::system_clock::now().time_since_epoch()).count();
    const auto elapsed = std::chrono::duration<double, std::milli>(Clock::now() - start).count();
    out << "event=" << name << " epoch_ms=" << ms << " elapsed_ms=" << elapsed << '\n' << std::flush;
}

void set_batch_token(llama_batch& batch, int index, llama_token token,
                     llama_pos position, bool request_logits) {
    batch.token[index] = token;
    batch.pos[index] = position;
    batch.n_seq_id[index] = 1;
    batch.seq_id[index][0] = 0;
    batch.logits[index] = request_logits;
}

}  // namespace

int main(int argc, char** argv) {
    if (argc != 6) {
        std::cerr << "usage: llama-m31-0002t-reference MODEL.gguf PROMPT_TOKENS OUTPUT_TOKENS METRICS_FILE GENERATED_IDS_FILE\n";
        return 2;
    }

    const std::filesystem::path metrics_path = argv[4];
    const std::filesystem::path ids_path = argv[5];
    if (std::filesystem::exists(metrics_path) || std::filesystem::exists(ids_path)) {
        std::cerr << "refusing to overwrite result artifact\n";
        return 2;
    }

    bool backend_initialized = false;
    try {
        const auto prompt_size = static_cast<std::size_t>(std::stoul(argv[2]));
        const auto output_size = static_cast<std::size_t>(std::stoul(argv[3]));
        if (prompt_size != 8192 || output_size == 0 || output_size > 128) {
            throw std::runtime_error("this diagnostic is bounded to an 8K prompt and 1-128 output tokens");
        }

        auto prompt = m31_0002::make_prompt(prompt_size, 77);
        const auto prompt_fingerprint = m31_0002::prompt_fingerprint(prompt);
        llama_backend_init();
        backend_initialized = true;
        auto model_params = llama_model_default_params();
        model_params.n_gpu_layers = 99;
        model_params.main_gpu = 0;
        model_params.split_mode = LLAMA_SPLIT_MODE_NONE;
        std::unique_ptr<llama_model, decltype(&llama_model_free)> model(
            llama_model_load_from_file(argv[1], model_params), llama_model_free);
        if (!model) throw std::runtime_error("llama_model_load_from_file failed");

        auto context_params = llama_context_default_params();
        context_params.n_ctx = prompt_size + 256;
        context_params.n_batch = 512;
        context_params.n_ubatch = 512;
        context_params.n_seq_max = 1;
        context_params.type_k = GGML_TYPE_F16;
        context_params.type_v = GGML_TYPE_F16;
        context_params.flash_attn_type = LLAMA_FLASH_ATTN_TYPE_AUTO;
        context_params.offload_kqv = true;
        context_params.no_perf = true;
        std::unique_ptr<llama_context, decltype(&llama_free)> context(
            llama_init_from_model(model.get(), context_params), llama_free);
        if (!context) throw std::runtime_error("llama_init_from_model failed");

        const auto* vocab = llama_model_get_vocab(model.get());
        const int vocab_size = llama_vocab_n_tokens(vocab);
        for (const auto token : prompt) {
            if (token >= static_cast<std::uint32_t>(vocab_size)) {
                throw std::runtime_error("shared prompt token is outside llama vocabulary");
            }
        }
        auto sampler_params = llama_sampler_chain_default_params();
        sampler_params.no_perf = true;
        std::unique_ptr<llama_sampler, decltype(&llama_sampler_free)> sampler(
            llama_sampler_chain_init(sampler_params), llama_sampler_free);
        if (!sampler) throw std::runtime_error("llama_sampler_chain_init failed");
        llama_sampler_chain_add(sampler.get(), llama_sampler_init_greedy());

        std::ofstream metrics(metrics_path);
        if (!metrics) throw std::runtime_error("cannot create metrics file");
        std::ofstream ids(ids_path);
        if (!ids) throw std::runtime_error("cannot create generated-token file");
        metrics << "model_path=" << argv[1] << "\nprompt_tokens=" << prompt.size()
                << "\ngenerate_tokens=" << output_size << "\nprompt_seed=77"
                << "\nprompt_fingerprint_fnv1a64=" << std::hex << prompt_fingerprint << std::dec
                << "\ncontext_tokens=" << context_params.n_ctx << "\n" << std::flush;
        const auto call_start = Clock::now();
        event(metrics, "CALL_START", call_start);

        auto batch = llama_batch_init(512, 0, 1);
        event(metrics, "PREFILL_START", call_start);
        const auto prefill_start = Clock::now();
        constexpr std::size_t batch_capacity = 512;
        for (std::size_t base = 0; base < prompt.size(); base += batch_capacity) {
            const int count = static_cast<int>(std::min<std::size_t>(
                batch_capacity, prompt.size() - base));
            batch.n_tokens = count;
            for (int i = 0; i < count; ++i) {
                const auto position = base + static_cast<std::size_t>(i);
                set_batch_token(batch, i, static_cast<llama_token>(prompt[position]),
                                static_cast<llama_pos>(position), position + 1 == prompt.size());
            }
            const int status = llama_decode(context.get(), batch);
            if (status != 0) {
                llama_batch_free(batch);
                throw std::runtime_error("llama_decode failed during prompt prefill: " + std::to_string(status));
            }
        }
        std::vector<llama_token> generated;
        generated.reserve(output_size);
        generated.push_back(llama_sampler_sample(sampler.get(), context.get(), -1));
        event(metrics, "PREFILL_END", call_start);
        const auto decode_start = Clock::now();
        event(metrics, "DECODE_START", call_start);

        for (std::size_t i = 1; i < output_size; ++i) {
            batch.n_tokens = 1;
            set_batch_token(batch, 0, generated.back(),
                            static_cast<llama_pos>(prompt.size() + i - 1), true);
            const int status = llama_decode(context.get(), batch);
            if (status != 0) {
                llama_batch_free(batch);
                throw std::runtime_error("llama_decode failed during generation: " + std::to_string(status));
            }
            generated.push_back(llama_sampler_sample(sampler.get(), context.get(), -1));
        }
        const auto decode_end = Clock::now();
        event(metrics, "DECODE_END", call_start);
        llama_batch_free(batch);

        const auto prefill_ms = std::chrono::duration<double, std::milli>(decode_start - prefill_start).count();
        const auto decode_ms = std::chrono::duration<double, std::milli>(decode_end - decode_start).count();
        for (const auto token : generated) ids << token << '\n';
        ids.flush();
        metrics << std::fixed << std::setprecision(3)
                << "result={\"prompt_tokens\":" << prompt.size()
                << ",\"generated_tokens\":" << generated.size()
                << ",\"decode_steps\":" << (generated.size() - 1)
                << ",\"prefill_ms\":" << prefill_ms
                << ",\"prefill_tok_s\":" << (prompt.size() * 1000.0 / prefill_ms)
                << ",\"decode_ms\":" << decode_ms
                << ",\"decode_tok_s\":" << ((generated.size() - 1) * 1000.0 / decode_ms)
                << "}\n" << std::flush;
        event(metrics, "CALL_COMPLETE", call_start);
        sampler.reset();
        context.reset();
        model.reset();
        llama_backend_free();
        backend_initialized = false;
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "M31-0002T llama reference failed: " << error.what() << '\n';
        if (backend_initialized) llama_backend_free();
        return 1;
    }
}
