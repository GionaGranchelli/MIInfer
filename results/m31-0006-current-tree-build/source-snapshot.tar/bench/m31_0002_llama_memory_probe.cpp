#include <ggml-backend.h>
#include <llama-ext.h>
#include <llama.h>

#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>

namespace {

void print_memory(const llama_context * context, const llama_model * model,
                  const char * stage, std::uint32_t prompt_tokens) {
    std::size_t model_bytes = 0, context_bytes = 0, compute_bytes = 0;
    const auto breakdown = llama_get_memory_breakdown(context);
    for (const auto &[buft, bytes] : breakdown) {
        std::cout << "buffer_type=" << ggml_backend_buft_name(buft)
                  << " stage=" << stage
                  << " model_bytes=" << bytes.model
                  << " context_bytes=" << bytes.context
                  << " compute_bytes=" << bytes.compute << '\n';
        model_bytes += bytes.model;
        context_bytes += bytes.context;
        compute_bytes += bytes.compute;
    }
    std::cout << "ledger stage=" << stage << " prompt_tokens=" << prompt_tokens
              << " llama_n_ctx=" << llama_n_ctx(context)
              << " model_bytes=" << model_bytes
              << " context_bytes=" << context_bytes
              << " compute_bytes=" << compute_bytes
              << " total_bytes=" << model_bytes + context_bytes + compute_bytes << '\n';
    for (int i = 0; i < llama_model_n_devices(model); ++i) {
        auto * device = llama_model_get_device(model, i);
        std::size_t free_bytes = 0, total_bytes = 0;
        ggml_backend_dev_memory(device, &free_bytes, &total_bytes);
        std::cout << "device=" << ggml_backend_dev_name(device)
                  << " free_bytes=" << free_bytes
                  << " total_bytes=" << total_bytes << '\n';
    }
    std::cout << std::flush;
}

void print_device_memory(const llama_model * model, const char * stage) {
    for (int i = 0; i < llama_model_n_devices(model); ++i) {
        auto * device = llama_model_get_device(model, i);
        std::size_t free_bytes = 0, total_bytes = 0;
        ggml_backend_dev_memory(device, &free_bytes, &total_bytes);
        std::cout << "device=" << ggml_backend_dev_name(device)
                  << " stage=" << stage
                  << " free_bytes=" << free_bytes
                  << " total_bytes=" << total_bytes
                  << " used_bytes=" << total_bytes - free_bytes << '\n';
    }
    std::cout << std::flush;
}

} // namespace

int main(int argc, char ** argv) {
    if (argc < 3) {
        std::cerr << "usage: llama-memory-probe MODEL.gguf PROMPT_TOKENS [...]\n";
        return 2;
    }

    std::vector<std::uint32_t> prompt_sizes;
    for (int i = 2; i < argc; ++i) {
        char * end = nullptr;
        const auto value = std::strtoul(argv[i], &end, 10);
        if (end == argv[i] || *end != '\0' || value == 0 || value > 131072) {
            std::cerr << "invalid prompt size: " << argv[i] << '\n';
            return 2;
        }
        prompt_sizes.push_back(static_cast<std::uint32_t>(value));
    }

    llama_backend_init();
    std::cout << "event=MODEL_LOAD_BEGIN\n" << std::flush;
    auto model_params = llama_model_default_params();
    model_params.n_gpu_layers = 99;
    auto * model = llama_model_load_from_file(argv[1], model_params);
    if (model == nullptr) {
        std::cerr << "failed to load model\n";
        llama_backend_free();
        return 1;
    }
    std::cout << "event=MODEL_READY\n" << std::flush;
    print_device_memory(model, "model_ready_zero_context");

    const auto * vocab = llama_model_get_vocab(model);
    llama_token token = llama_vocab_bos(vocab);
    if (token < 0) token = 1;
    for (const auto prompt_tokens : prompt_sizes) {
        auto params = llama_context_default_params();
        params.n_ctx = prompt_tokens + 32; // llama-bench -n 32 context sizing
        params.n_batch = 2048;
        params.n_ubatch = 512;
        params.n_seq_max = 1;
        params.type_k = GGML_TYPE_F16;
        params.type_v = GGML_TYPE_F16;
        params.flash_attn_type = LLAMA_FLASH_ATTN_TYPE_AUTO;
        params.offload_kqv = true;
        params.no_perf = true;

        auto * context = llama_init_from_model(model, params);
        if (context == nullptr) {
            std::cerr << "failed to create context for prompt=" << prompt_tokens << '\n';
            llama_model_free(model);
            llama_backend_free();
            return 1;
        }
        std::cout << "event=CONTEXT_READY prompt_tokens=" << prompt_tokens
                  << " requested_context=" << prompt_tokens + 32
                  << " actual_context=" << llama_n_ctx(context) << '\n' << std::flush;
        print_memory(context, model, "context_ready", prompt_tokens);

        auto batch = llama_batch_init(512, 0, 1);
        batch.n_tokens = 512;
        for (int i = 0; i < batch.n_tokens; ++i) {
            batch.token[i] = token;
            batch.pos[i] = i;
            batch.n_seq_id[i] = 1;
            batch.seq_id[i][0] = 0;
            batch.logits[i] = (i == 511);
        }
        const int decode_status = llama_decode(context, batch);
        llama_batch_free(batch);
        if (decode_status != 0) {
            std::cerr << "one 512-token memory-probe batch failed, status="
                      << decode_status << " prompt=" << prompt_tokens << '\n';
            llama_free(context);
            llama_model_free(model);
            llama_backend_free();
            return 1;
        }
        print_memory(context, model, "after_probe_batch512", prompt_tokens);
        llama_free(context);
    }

    llama_model_free(model);
    llama_backend_free();
    return 0;
}
