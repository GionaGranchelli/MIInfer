#include "miinfer/hip_check.hpp"
#include "miinfer/m12_gdn_chunk.hpp"
#include "miinfer/prefill_v2/constants.hpp"

#include <hip/hip_runtime.h>

#include <cmath>
#include <cstdint>
#include <iostream>
#include <vector>

namespace {

std::uint64_t hash_bytes(std::uint64_t hash, const void* data, std::size_t bytes) {
    const auto* input = static_cast<const std::uint8_t*>(data);
    for (std::size_t i = 0; i < bytes; ++i) {
        hash ^= input[i];
        hash *= 1099511628211ULL;
    }
    return hash;
}

struct DeviceBuffer {
    float* data = nullptr;
    explicit DeviceBuffer(std::size_t elements) { MIINFER_HIP_CHECK(hipMalloc(&data, elements * sizeof(float))); }
    ~DeviceBuffer() { if (data != nullptr) (void)hipFree(data); }
    DeviceBuffer(const DeviceBuffer&) = delete;
};

void fill(std::vector<float>& values, std::uint32_t seed) {
    std::uint32_t value = seed;
    for (auto& element : values) {
        value = value * 1664525u + 1013904223u;
        element = (static_cast<float>(value % 2001u) - 1000.0F) / 1000.0F;
    }
}

} // namespace

int main() {
    constexpr std::size_t state_size = miinfer::prefill_v2::kState;
    constexpr std::size_t key_heads = miinfer::prefill_v2::kKHeads;
    constexpr std::size_t value_heads = miinfer::prefill_v2::kVHeads;
    const std::size_t state_elements = value_heads * state_size * state_size;
    const std::size_t qk_elements = key_heads * state_size;
    const std::size_t value_elements = value_heads * state_size;

    try {
        hipStream_t stream = nullptr;
        MIINFER_HIP_CHECK(hipStreamCreate(&stream));
        std::vector<float> initial(state_elements);
        std::vector<float> q1(qk_elements), k1(qk_elements), v1(value_elements), b1(value_heads), d1(value_heads);
        std::vector<float> q2(qk_elements), k2(qk_elements), v2(value_elements), b2(value_heads), d2(value_heads);
        fill(initial, 11); fill(q1, 12); fill(k1, 13); fill(v1, 14); fill(b1, 15); fill(d1, 16);
        fill(q2, 17); fill(k2, 18); fill(v2, 19); fill(b2, 20); fill(d2, 21);
        for (auto& element : b1) element = 0.05F + std::abs(element) * 0.2F;
        for (auto& element : b2) element = 0.05F + std::abs(element) * 0.2F;
        for (auto& element : d1) element = 0.8F + std::abs(element) * 0.15F;
        for (auto& element : d2) element = 0.8F + std::abs(element) * 0.15F;

        DeviceBuffer state_a(state_elements), state_b(state_elements), q(qk_elements), k(qk_elements), v(value_elements), beta(value_heads), decay(value_heads), output(value_elements);
        MIINFER_HIP_CHECK(hipMemcpy(state_a.data, initial.data(), initial.size() * sizeof(float), hipMemcpyHostToDevice));
        MIINFER_HIP_CHECK(hipMemcpy(q.data, q1.data(), q1.size() * sizeof(float), hipMemcpyHostToDevice));
        MIINFER_HIP_CHECK(hipMemcpy(k.data, k1.data(), k1.size() * sizeof(float), hipMemcpyHostToDevice));
        MIINFER_HIP_CHECK(hipMemcpy(v.data, v1.data(), v1.size() * sizeof(float), hipMemcpyHostToDevice));
        MIINFER_HIP_CHECK(hipMemcpy(beta.data, b1.data(), b1.size() * sizeof(float), hipMemcpyHostToDevice));
        MIINFER_HIP_CHECK(hipMemcpy(decay.data, d1.data(), d1.size() * sizeof(float), hipMemcpyHostToDevice));

        miinfer::launch_mx_gdn_chunk(q.data, k.data, v.data, beta.data, decay.data, state_a.data, output.data, 1, key_heads, value_heads, state_size, stream);
        MIINFER_HIP_CHECK(hipStreamSynchronize(stream));
        MIINFER_HIP_CHECK(hipMemcpy(state_b.data, state_a.data, state_elements * sizeof(float), hipMemcpyDeviceToDevice));
        MIINFER_HIP_CHECK(hipStreamSynchronize(stream));

        MIINFER_HIP_CHECK(hipMemcpy(q.data, q2.data(), q2.size() * sizeof(float), hipMemcpyHostToDevice));
        MIINFER_HIP_CHECK(hipMemcpy(k.data, k2.data(), k2.size() * sizeof(float), hipMemcpyHostToDevice));
        MIINFER_HIP_CHECK(hipMemcpy(v.data, v2.data(), v2.size() * sizeof(float), hipMemcpyHostToDevice));
        MIINFER_HIP_CHECK(hipMemcpy(beta.data, b2.data(), b2.size() * sizeof(float), hipMemcpyHostToDevice));
        MIINFER_HIP_CHECK(hipMemcpy(decay.data, d2.data(), d2.size() * sizeof(float), hipMemcpyHostToDevice));
        miinfer::launch_mx_gdn_chunk(q.data, k.data, v.data, beta.data, decay.data, state_a.data, output.data, 1, key_heads, value_heads, state_size, stream);
        miinfer::launch_mx_gdn_chunk(q.data, k.data, v.data, beta.data, decay.data, state_b.data, output.data, 1, key_heads, value_heads, state_size, stream);
        MIINFER_HIP_CHECK(hipStreamSynchronize(stream));

        std::vector<float> actual_a(state_elements), actual_b(state_elements);
        MIINFER_HIP_CHECK(hipMemcpy(actual_a.data(), state_a.data, actual_a.size() * sizeof(float), hipMemcpyDeviceToHost));
        MIINFER_HIP_CHECK(hipMemcpy(actual_b.data(), state_b.data, actual_b.size() * sizeof(float), hipMemcpyDeviceToHost));
        double max_error = 0.0;
        for (std::size_t i = 0; i < actual_a.size(); ++i) max_error = std::max(max_error, std::abs(static_cast<double>(actual_a[i] - actual_b[i])));
        const auto hash_a = hash_bytes(1469598103934665603ULL, actual_a.data(), actual_a.size() * sizeof(float));
        const auto hash_b = hash_bytes(1469598103934665603ULL, actual_b.data(), actual_b.size() * sizeof(float));
        std::cout << "M31R-0001 gdn-state-copy: " << (max_error == 0.0 ? "PASS" : "FAIL")
                  << " max_error=" << max_error << " hash_a=0x" << std::hex << hash_a << " hash_b=0x" << hash_b << std::dec << '\n';
        MIINFER_HIP_CHECK(hipStreamDestroy(stream));
        return max_error == 0.0 ? 0 : 1;
    } catch (const std::exception& error) {
        std::cerr << "M31R-0001 gdn-state-copy: ERROR: " << error.what() << '\n';
        return 1;
    }
}
